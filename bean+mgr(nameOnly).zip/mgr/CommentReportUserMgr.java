package mgr;

public class CommentReportUserMgr {
	
}
