package mgr;

public class UserMgr {
	
}
