package mgr;

public class PostReportMgr {
	
}
