package mgr;

public class DeletedCommentMgr {
	
}
