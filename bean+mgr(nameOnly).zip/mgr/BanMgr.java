package mgr;

public class BanMgr {
	
}
