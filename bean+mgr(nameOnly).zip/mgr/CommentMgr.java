package mgr;

public class CommentMgr {
	
}
