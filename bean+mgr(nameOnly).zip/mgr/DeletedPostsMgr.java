package mgr;

public class DeletedPostsMgr {
	
}
