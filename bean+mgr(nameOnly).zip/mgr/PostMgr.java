package mgr;

public class PostMgr {
	
}
