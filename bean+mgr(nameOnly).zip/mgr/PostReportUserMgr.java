package mgr;

public class PostReportUserMgr {
	
}
