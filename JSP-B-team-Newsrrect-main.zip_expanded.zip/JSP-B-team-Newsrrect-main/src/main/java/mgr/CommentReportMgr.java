package mgr;

public class CommentReportMgr {
	
}
