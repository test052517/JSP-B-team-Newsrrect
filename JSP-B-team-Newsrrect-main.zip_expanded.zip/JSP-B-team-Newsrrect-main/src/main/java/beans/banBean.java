package beans;

public class banBean {
	private int banId;
    private int banUser;
    private String nickname;
    private String reason;
    private String banDate;
    
	public int getBanId() {
		return banId;
	}
	public void setBanId(int banId) {
		this.banId = banId;
	}
	public int getBanUser() {
		return banUser;
	}
	public void setBanUser(int banUser) {
		this.banUser = banUser;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getBanDate() {
		return banDate;
	}
	public void setBanDate(String banDate) {
		this.banDate = banDate;
	}
}
