package beans;

public class commentReportBean {
	private int reportCommentId;
    private int commentId;
    private String type;
    private String reason;
    private Integer attachmentId;
    private int reportedId;
    
	public int getReportCommentId() {
		return reportCommentId;
	}
	public void setReportCommentId(int reportCommentId) {
		this.reportCommentId = reportCommentId;
	}
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Integer getAttachmentId() {
		return attachmentId;
	}
	public void setAttachmentId(Integer attachmentId) {
		this.attachmentId = attachmentId;
	}
	public int getReportedId() {
		return reportedId;
	}
	public void setReportedId(int reportedId) {
		this.reportedId = reportedId;
	}
}
