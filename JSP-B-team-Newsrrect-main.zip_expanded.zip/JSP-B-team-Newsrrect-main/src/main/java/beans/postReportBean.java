package beans;

public class postReportBean {
	private int reportPostId;
    private String title;
    private int postId;
    private String type;
    private String reason;
    private Integer attachmentId;
    private int reportedId;
    
	public int getReportPostId() {
		return reportPostId;
	}
	public void setReportPostId(int reportPostId) {
		this.reportPostId = reportPostId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Integer getAttachmentId() {
		return attachmentId;
	}
	public void setAttachmentId(Integer attachmentId) {
		this.attachmentId = attachmentId;
	}
	public int getReportedId() {
		return reportedId;
	}
	public void setReportedId(int reportedId) {
		this.reportedId = reportedId;
	}
}
