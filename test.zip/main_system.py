from flask import Flask, render_template, request, jsonify
import json
from datetime import datetime
from typing import Dict, List
import traceback
import time
import socket

# 우리가 만든 모듈들 import
from config import Config
from database import DatabaseManager
from keyword_extractor import KeywordExtractor
from news_searcher import NaverNewsSearcher
from news_analyzer import NewsAnalyzer

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

class NewsAnalysisSystem:
    def __init__(self):
        self.db_manager = DatabaseManager()
        self.keyword_extractor = KeywordExtractor()
        self.news_searcher = NaverNewsSearcher()
        self.news_analyzer = NewsAnalyzer()
    
    def analyze_news_url(self, url: str) -> Dict:
        """전체 뉴스 분석 프로세스"""
        start_time = time.time()
        
        try:
            print(f"뉴스 분석 시작: {url}")
            
            # 1단계: 키워드 추출
            print("1단계: 키워드 추출 중...")
            keyword_result = self.keyword_extractor.extract_keywords_from_url(url)
            
            if not keyword_result['success']:
                return {
                    'success': False,
                    'error': f"키워드 추출 실패: {keyword_result['error']}",
                    'stage': 'keyword_extraction'
                }
            
            keywords = keyword_result['keywords']
            print(f"추출된 키워드: {keywords}")
            
            # 키워드 추출 로그 저장
            self.db_manager.save_keyword_extraction(url, keywords, 'cohere')
            
            # 2단계: 네이버 뉴스 검색
            print("2단계: 관련 뉴스 검색 중...")
            search_result = self.news_searcher.get_top_articles(keywords)
            
            if not search_result['success']:
                return {
                    'success': False,
                    'error': f"뉴스 검색 실패: {search_result.get('error', '알 수 없는 오류')}",
                    'stage': 'news_search',
                    'keywords': keywords
                }
            
            articles = search_result['top_articles']
            print(f"검색된 관련 뉴스: {len(articles)}건")
            
            if not articles:
                return {
                    'success': False,
                    'error': "관련 뉴스를 찾을 수 없습니다.",
                    'stage': 'news_search',
                    'keywords': keywords
                }
            
            # 3단계: 뉴스 DB 저장
            print("3단계: 뉴스 DB 저장 중...")
            saved_count = self.db_manager.save_news_articles(articles, keywords)
            print(f"저장된 뉴스: {saved_count}건")
            
            # 4단계: AI 분석 및 교차검증
            print("4단계: AI 분석 및 교차검증 중...")
            analysis_result = self.news_analyzer.generate_fact_check_report(articles, keywords)
            
            if not analysis_result['success']:
                return {
                    'success': False,
                    'error': f"분석 실패: {analysis_result['error']}",
                    'stage': 'analysis',
                    'keywords': keywords,
                    'articles_found': len(articles)
                }
            
            report = analysis_result['report']
            
            # 처리 시간 계산
            processing_time = time.time() - start_time
            
            # 5단계: 결과 저장
            result_id = self.db_manager.save_analysis_result(
                url, keywords, len(articles),
                report['summary'], report['reliability_score'],
                report['verification_details']
            )
            
            print(f"분석 완료! (처리시간: {processing_time:.2f}초)")
            
            return {
                'success': True,
                'result_id': result_id,
                'original_url': url,
                'keywords': keywords,
                'articles_analyzed': len(articles),
                'summary': report['summary'],
                'reliability_score': report['reliability_score'],
                'verification_details': report['verification_details'],
                'sentiment_analysis': report.get('sentiment_analysis', ''),
                'articles_info': report['articles_info'],
                'search_summary': search_result.get('search_summary', {}),
                'analysis_date': report['analysis_date'],
                'processing_time': round(processing_time, 2)
            }
            
        except Exception as e:
            error_msg = f"시스템 오류: {str(e)}"
            print(error_msg)
            traceback.print_exc()
            
            return {
                'success': False,
                'error': error_msg,
                'stage': 'system_error'
            }

# 시스템 인스턴스 생성
news_system = NewsAnalysisSystem()

# 웹 라우트들
@app.route('/')
def index():
    """메인 페이지"""
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze_news():
    """뉴스 분석 API"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        
        if not url:
            return jsonify({
                'success': False,
                'error': 'URL을 입력해주세요.'
            })
        
        # URL 유효성 간단 검증
        if not (url.startswith('http://') or url.startswith('https://')):
            return jsonify({
                'success': False,
                'error': '올바른 URL 형식이 아닙니다.'
            })
        
        # 뉴스 분석 실행
        result = news_system.analyze_news_url(url)
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'서버 오류: {str(e)}'
        })

@app.route('/history')
def get_history():
    """분석 기록 조회"""
    try:
        limit = request.args.get('limit', 20, type=int)
        history = news_system.db_manager.get_analysis_history(limit)
        
        return jsonify({
            'success': True,
            'history': history
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'기록 조회 오류: {str(e)}'
        })

@app.route('/result/<int:result_id>')
def get_result_detail(result_id):
    """특정 분석 결과 상세 조회"""
    try:
        result = news_system.db_manager.get_analysis_by_id(result_id)
        
        if not result:
            return jsonify({
                'success': False,
                'error': '해당 분석 결과를 찾을 수 없습니다.'
            })
        
        return jsonify({
            'success': True,
            'result': result
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'결과 조회 오류: {str(e)}'
        })

@app.route('/dashboard')
def dashboard():
    """대시보드 페이지"""
    return render_template('dashboard.html')

@app.route('/api/stats')
def get_stats():
    """통계 정보 API"""
    try:
        # 데이터베이스에서 통계 조회
        stats = news_system.db_manager.get_statistics()
        history = news_system.db_manager.get_analysis_history(10)
        
        return jsonify({
            'success': True,
            'stats': {
                'total_analyses': stats['total_analyses'],
                'average_reliability': stats['average_reliability'],
                'reliability_distribution': stats['reliability_distribution'],
                'today_analyses': stats['today_analyses'],
                'recent_analyses': history
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'통계 조회 오류: {str(e)}'
        })

@app.route('/api/keywords/<path:url>')
def extract_keywords_only(url):
    """키워드만 추출하는 API"""
    try:
        result = news_system.keyword_extractor.extract_keywords_from_url(url)
        
        if result['success']:
            return jsonify({
                'success': True,
                'keywords': result['keywords'],
                'title': result['content_data']['title'],
                'domain': result['content_data']['domain']
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'키워드 추출 오류: {str(e)}'
        })

@app.route('/api/search')
def search_news():
    """뉴스 검색 API"""
    try:
        keywords = request.args.get('keywords', '').split(',')
        keywords = [k.strip() for k in keywords if k.strip()]
        
        if not keywords:
            return jsonify({
                'success': False,
                'error': '검색할 키워드를 입력해주세요.'
            })
        
        count = request.args.get('count', 10, type=int)
        result = news_system.news_searcher.get_top_articles(keywords, count)
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'뉴스 검색 오류: {str(e)}'
        })

@app.route('/api/analyze-text', methods=['POST'])
def analyze_text():
    """텍스트 직접 분석 API"""
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        
        if not text:
            return jsonify({
                'success': False,
                'error': '분석할 텍스트를 입력해주세요.'
            })
        
        # 키워드 추출
        keywords = news_system.keyword_extractor.extract_keywords_with_cohere(text)
        
        if not keywords:
            return jsonify({
                'success': False,
                'error': '키워드를 추출할 수 없습니다.'
            })
        
        # 관련 뉴스 검색
        search_result = news_system.news_searcher.get_top_articles(keywords)
        
        if search_result['success'] and search_result['top_articles']:
            # 분석 수행
            analysis_result = news_system.news_analyzer.generate_fact_check_report(
                search_result['top_articles'], keywords
            )
            
            if analysis_result['success']:
                report = analysis_result['report']
                return jsonify({
                    'success': True,
                    'keywords': keywords,
                    'articles_count': len(search_result['top_articles']),
                    'summary': report['summary'],
                    'reliability_score': report['reliability_score'],
                    'verification_details': report['verification_details']
                })
        
        return jsonify({
            'success': False,
            'error': '관련 뉴스를 찾을 수 없거나 분석에 실패했습니다.'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'텍스트 분석 오류: {str(e)}'
        })

@app.route('/api/cleanup')
def cleanup_data():
    """오래된 데이터 정리 API"""
    try:
        days = request.args.get('days', 30, type=int)
        deleted_count = news_system.db_manager.cleanup_old_data(days)
        
        return jsonify({
            'success': True,
            'message': f'{days}일 이전 데이터 {deleted_count}건이 삭제되었습니다.',
            'deleted_count': deleted_count
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'데이터 정리 오류: {str(e)}'
        })

@app.route('/health')
def health_check():
    """시스템 상태 확인"""
    try:
        # 데이터베이스 연결 테스트
        db_status = news_system.db_manager.test_connection()
        
        # 기본 통계 조회
        stats = news_system.db_manager.get_statistics()
        
        return jsonify({
            'status': 'healthy' if db_status else 'unhealthy',
            'database': 'connected' if db_status else 'disconnected',
            'timestamp': datetime.now().isoformat(),
            'stats': stats
        })
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        })

# 에러 핸들러
@app.errorhandler(404)
def not_found_error(error):
    return jsonify({
        'success': False,
        'error': '요청한 페이지를 찾을 수 없습니다.'
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'success': False,
        'error': '서버 내부 오류가 발생했습니다.'
    }), 500

# CLI 모드 함수
def run_cli_mode():
    """CLI 모드로 시스템 실행"""
    print("=== 뉴스 분석 시스템 CLI 모드 ===")
    print("종료하려면 'quit', 'exit', 'q'를 입력하세요.\n")
    
    while True:
        try:
            url = input("📰 분석할 뉴스 URL을 입력하세요: ").strip()
            
            if url.lower() in ['quit', 'exit', 'q']:
                print("👋 프로그램을 종료합니다.")
                break
            
            if not url:
                continue
            
            if not (url.startswith('http://') or url.startswith('https://')):
                print("❌ 올바른 URL 형식이 아닙니다. http:// 또는 https://로 시작해야 합니다.\n")
                continue
            
            print("\n" + "="*60)
            print("🔄 분석을 시작합니다...")
            
            result = news_system.analyze_news_url(url)
            
            if result['success']:
                print("✅ 분석 완료!")
                print(f"📊 신뢰성 점수: {result['reliability_score']:.1f}%")
                print(f"📰 분석 기사 수: {result['articles_analyzed']}건")
                print(f"🏷️  키워드: {', '.join(result['keywords'])}")
                print(f"⏱️  처리시간: {result['processing_time']}초")
                print(f"\n📄 요약:")
                print(result['summary'])
                print(f"\n🔬 검증 상세:")
                print(result['verification_details'])
                
                if result.get('sentiment_analysis'):
                    print(f"\n💭 감정 분석:")
                    print(result['sentiment_analysis'])
                    
            else:
                print(f"❌ 분석 실패: {result['error']}")
                if 'stage' in result:
                    print(f"실패 단계: {result['stage']}")
            
            print("="*60 + "\n")
            
        except KeyboardInterrupt:
            print("\n👋 CLI를 종료합니다.")
            break
        except Exception as e:
            print(f"❌ CLI 실행 오류: {e}")

def initialize_system():
    """시스템 초기화"""
    print("🔧 시스템 초기화 중...")
    
    try:
        # 데이터베이스 연결 테스트
        if not news_system.db_manager.test_connection():
            print("❌ 데이터베이스 연결 실패")
            return False
        
        print("✅ 시스템 초기화 완료")
        return True
        
    except Exception as e:
        print(f"❌ 시스템 초기화 실패: {e}")
        return False

if __name__ == "__main__":
    import sys
    
    # 시스템 초기화
    if not initialize_system():
        print("시스템을 시작할 수 없습니다.")
        sys.exit(1)
    
    if len(sys.argv) > 1 and sys.argv[1] == 'cli':
        run_cli_mode()
    else:
        # 현재 컴퓨터의 IP 주소 확인
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        
        print("🌐 뉴스 분석 시스템을 웹 서버 모드로 시작합니다...")
        print(f"🔗 로컬 접속: http://localhost:{Config.PORT}")
        print(f"🔗 로컬 접속: http://127.0.0.1:{Config.PORT}")
        print(f"🌍 네트워크 접속: http://{local_ip}:{Config.PORT}")
        print(f"⚙️  서버 호스트: {Config.HOST}:{Config.PORT}")
        print("ℹ️  종료하려면 Ctrl+C를 누르세요.")
        print("\n네트워크 내 다른 기기에서 접속하려면:")
        print(f"  - 같은 Wi-Fi에 연결")
        print(f"  - 브라우저에서 http://{local_ip}:{Config.PORT} 접속")
        print(f"  - 방화벽에서 포트 {Config.PORT} 허용 확인")
        
        try:
            app.run(
                host=Config.HOST, 
                port=Config.PORT, 
                debug=Config.DEBUG,
                threaded=True
            )
        except KeyboardInterrupt:
            print("\n👋 서버를 종료합니다.")
        except Exception as e:
            print(f"❌ 서버 실행 오류: {e}")