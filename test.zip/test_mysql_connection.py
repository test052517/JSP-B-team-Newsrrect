#!/usr/bin/env python3
"""
MySQL 연결 테스트 및 데이터베이스 설정 검증 스크립트
뉴스 분석 시스템의 MySQL 데이터베이스 연결을 테스트하고 설정을 검증합니다.
"""

import mysql.connector
import pymysql
from mysql.connector import Error
from config import Config
import sys
import traceback
from datetime import datetime

def print_header(title):
    """헤더 출력"""
    print("\n" + "=" * 60)
    print(f" {title}")
    print("=" * 60)

def print_step(step, description):
    """단계별 출력"""
    print(f"\n{step} {description}")
    print("-" * 40)

def test_mysql_connection():
    """MySQL 연결 테스트"""
    print_header("MySQL 연결 테스트")
    
    # 설정 정보 출력
    print(f"🔧 연결 설정:")
    print(f"   Host: {Config.MYSQL_HOST}")
    print(f"   Port: {Config.MYSQL_PORT}")
    print(f"   Database: {Config.MYSQL_DATABASE}")
    print(f"   User: {Config.MYSQL_USER}")
    print(f"   Password: {'*' * len(Config.MYSQL_PASSWORD) if Config.MYSQL_PASSWORD else '(비어있음)'}")
    print(f"   Charset: {Config.MYSQL_CHARSET}")
    
    success_count = 0
    
    # 1. mysql-connector-python 테스트
    print_step("1️⃣", "mysql-connector-python 테스트")
    try:
        connection = mysql.connector.connect(
            host=Config.MYSQL_HOST,
            port=Config.MYSQL_PORT,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DATABASE,
            charset=Config.MYSQL_CHARSET,
            autocommit=True
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            # MySQL 버전 확인
            cursor.execute("SELECT VERSION()")
            version = cursor.fetchone()
            print(f"   ✅ 연결 성공! MySQL 버전: {version[0]}")
            
            # 데이터베이스 정보 확인
            cursor.execute("SELECT DATABASE()")
            current_db = cursor.fetchone()
            print(f"   📊 현재 데이터베이스: {current_db[0]}")
            
            # 테이블 존재 확인
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            print(f"   🗂️  테이블 수: {len(tables)}개")
            
            if tables:
                print(f"   📋 존재하는 테이블:")
                for table in tables:
                    cursor.execute(f"SELECT COUNT(*) FROM {table[0]}")
                    count = cursor.fetchone()[0]
                    print(f"      - {table[0]}: {count}건")
            
            # 연결 권한 확인
            cursor.execute("SHOW GRANTS FOR CURRENT_USER()")
            grants = cursor.fetchall()
            print(f"   🔐 사용자 권한: {len(grants)}개 권한 보유")
            
            cursor.close()
            connection.close()
            success_count += 1
            
    except Error as e:
        print(f"   ❌ mysql-connector-python 연결 실패: {e}")
        print(f"   📝 오류 코드: {e.errno}")
        print(f"   📝 SQL 상태: {e.sqlstate}")
    
    # 2. PyMySQL 테스트
    print_step("2️⃣", "PyMySQL 테스트")
    try:
        connection = pymysql.connect(
            host=Config.MYSQL_HOST,
            port=Config.MYSQL_PORT,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DATABASE,
            charset=Config.MYSQL_CHARSET,
            autocommit=True
        )
        
        with connection.cursor() as cursor:
            # MySQL 서버 정보
            cursor.execute("SELECT VERSION()")
            version = cursor.fetchone()
            print(f"   ✅ 연결 성공! MySQL 버전: {version[0]}")
            
            # 서버 상태 확인
            cursor.execute("SHOW STATUS LIKE 'Uptime'")
            uptime = cursor.fetchone()
            uptime_hours = int(uptime[1]) // 3600
            print(f"   ⏱️  서버 가동시간: {uptime_hours}시간")
            
            # 연결 수 확인
            cursor.execute("SHOW STATUS LIKE 'Threads_connected'")
            connections = cursor.fetchone()
            print(f"   🔗 현재 연결 수: {connections[1]}개")
            
            # 데이터베이스 크기 확인
            cursor.execute(f"""
            SELECT 
                table_schema as 'Database',
                ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as 'Size (MB)'
            FROM information_schema.tables 
            WHERE table_schema = '{Config.MYSQL_DATABASE}'
            GROUP BY table_schema
            """)
            
            size_info = cursor.fetchone()
            if size_info:
                print(f"   💾 데이터베이스 크기: {size_info[1]} MB")
        
        connection.close()
        success_count += 1
        
    except Exception as e:
        print(f"   ❌ PyMySQL 연결 실패: {e}")
    
    return success_count >= 1

def test_database_operations():
    """기본적인 데이터베이스 작업 테스트"""
    print_header("데이터베이스 작업 테스트")
    
    try:
        from database import DatabaseManager
        
        print_step("1️⃣", "DatabaseManager 초기화")
        db = DatabaseManager()
        print("   ✅ DatabaseManager 객체 생성 완료")
        
        print_step("2️⃣", "데이터베이스 연결 테스트")
        if not db.test_connection():
            print("   ❌ 데이터베이스 연결 실패")
            return False
        print("   ✅ 데이터베이스 연결 성공")
        
        print_step("3️⃣", "통계 조회 테스트")
        stats = db.get_statistics()
        print(f"   📊 현재 통계:")
        print(f"      - 총 분석: {stats['total_analyses']}건")
        print(f"      - 평균 신뢰도: {stats['average_reliability']}%")
        print(f"      - 고신뢰도: {stats['reliability_distribution']['high']}건")
        print(f"      - 중신뢰도: {stats['reliability_distribution']['medium']}건")
        print(f"      - 저신뢰도: {stats['reliability_distribution']['low']}건")
        print(f"      - 오늘 분석: {stats['today_analyses']}건")
        
        print_step("4️⃣", "분석 기록 조회 테스트")
        history = db.get_analysis_history(5)
        print(f"   📜 최근 분석 기록: {len(history)}건")
        
        for i, record in enumerate(history[:3], 1):
            keywords = record['keywords'][:50] + "..." if len(record['keywords']) > 50 else record['keywords']
            print(f"      {i}. 키워드: {keywords}")
            print(f"         신뢰도: {record['reliability_score']}%")
            print(f"         일시: {record['created_at']}")
        
        print_step("5️⃣", "테스트 데이터 삽입/삭제")
        test_url = f"https://test.com/news-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # 테스트 키워드 추출 로그
        db.save_keyword_extraction(
            test_url,
            ["테스트", "키워드", "MySQL", "연결"],
            "test_method"
        )
        print("   💾 테스트 키워드 추출 로그 저장 완료")
        
        # 테스트 뉴스 기사
        test_articles = [{
            'title': f'MySQL 연결 테스트 뉴스 - {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}',
            'description': '데이터베이스 연결 테스트를 위한 더미 뉴스입니다. 이 데이터는 테스트 후 삭제됩니다.',
            'link': test_url,
            'bloggername': '테스트 출처',
            'pub_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }]
        
        saved_count = db.save_news_articles(test_articles, ["MySQL", "테스트", "연결"])
        print(f"   💾 테스트 뉴스 저장: {saved_count}건")
        
        # 테스트 분석 결과
        result_id = db.save_analysis_result(
            test_url,
            ["MySQL", "테스트", "연결", "검증"],
            1,
            "MySQL 연결 테스트를 위한 더미 요약입니다.",
            85.5,
            "테스트용 분석 상세 내용입니다. 모든 검증 항목이 정상적으로 통과했습니다."
        )
        
        print(f"   📊 테스트 분석 결과 저장: ID {result_id}")
        
        # 저장된 데이터 확인
        if result_id:
            saved_result = db.get_analysis_by_id(result_id)
            if saved_result:
                print(f"   ✅ 저장된 데이터 조회 성공: {saved_result['summary'][:50]}...")
        
        print_step("6️⃣", "테이블 구조 검증")
        connection = db.get_connection()
        cursor = connection.cursor()
        
        # 필수 테이블 존재 확인
        required_tables = [
            'news_articles', 'analysis_results', 'keyword_extractions'
        ]
        
        cursor.execute("SHOW TABLES")
        existing_tables = [table[0] for table in cursor.fetchall()]
        
        for table in required_tables:
            if table in existing_tables:
                cursor.execute(f"DESCRIBE {table}")
                columns = cursor.fetchall()
                print(f"   ✅ {table}: {len(columns)}개 컬럼")
            else:
                print(f"   ❌ {table}: 테이블 없음")
        
        cursor.close()
        connection.close()
        
        print("\n✅ 모든 데이터베이스 작업 테스트 완료!")
        return True
        
    except ImportError as e:
        print(f"❌ 모듈 import 실패: {e}")
        print("   database.py 파일이 존재하는지 확인해주세요.")
        return False
    except Exception as e:
        print(f"❌ 데이터베이스 작업 테스트 실패: {e}")
        traceback.print_exc()
        return False

def check_mysql_requirements():
    """MySQL 관련 요구사항 확인"""
    print_header("MySQL 요구사항 확인")
    
    requirements_met = True
    
    # 1. Python 패키지 확인
    print_step("1️⃣", "Python 패키지 확인")
    
    packages = [
        ('mysql.connector', 'mysql-connector-python'),
        ('pymysql', 'PyMySQL'),
        ('dotenv', 'python-dotenv'),
        ('config', 'config.py (로컬 파일)')
    ]
    
    for module_name, package_name in packages:
        try:
            if module_name == 'mysql.connector':
                import mysql.connector
                print(f"   ✅ {package_name}: {mysql.connector.__version__}")
            elif module_name == 'pymysql':
                import pymysql
                print(f"   ✅ {package_name}: {pymysql.__version__}")
            elif module_name == 'dotenv':
                import dotenv
                print(f"   ✅ {package_name}: 설치됨")
            elif module_name == 'config':
                import config
                print(f"   ✅ {package_name}: 로드됨")
        except ImportError:
            print(f"   ❌ {package_name}: 설치되지 않음")
            if package_name != 'config.py (로컬 파일)':
                print(f"      설치: pip install {package_name}")
            requirements_met = False
    
    # 2. 환경변수 확인
    print_step("2️⃣", "환경변수 확인")
    
    env_vars = [
        ('MYSQL_HOST', Config.MYSQL_HOST),
        ('MYSQL_PORT', Config.MYSQL_PORT),
        ('MYSQL_USER', Config.MYSQL_USER),
        ('MYSQL_PASSWORD', Config.MYSQL_PASSWORD),
        ('MYSQL_DATABASE', Config.MYSQL_DATABASE)
    ]
    
    missing_vars = []
    for var_name, var_value in env_vars:
        if var_value and str(var_value).strip():
            if var_name == 'MYSQL_PASSWORD':
                print(f"   ✅ {var_name}: {'*' * len(str(var_value))}")
            else:
                print(f"   ✅ {var_name}: {var_value}")
        else:
            print(f"   ❌ {var_name}: 설정되지 않음")
            missing_vars.append(var_name)
            requirements_met = False
    
    if missing_vars:
        print(f"\n⚠️  누락된 환경변수: {', '.join(missing_vars)}")
        print("   .env 파일을 확인하고 다음 변수들을 설정해주세요:")
        for var in missing_vars:
            print(f"   {var}=your_value_here")
    
    # 3. .env 파일 확인
    print_step("3️⃣", ".env 파일 확인")
    try:
        import os
        env_file = '.env'
        if os.path.exists(env_file):
            print(f"   ✅ .env 파일 존재: {env_file}")
            with open(env_file, 'r') as f:
                lines = f.readlines()
            print(f"   📄 .env 파일 라인 수: {len(lines)}")
        else:
            print(f"   ❌ .env 파일 없음: {env_file}")
            print("   다음 명령어로 생성하세요: cp .env.example .env")
            requirements_met = False
    except Exception as e:
        print(f"   ❌ .env 파일 확인 실패: {e}")
        requirements_met = False
    
    return requirements_met

def run_performance_test():
    """성능 테스트"""
    print_header("성능 테스트")
    
    try:
        from database import DatabaseManager
        import time
        
        db = DatabaseManager()
        
        print_step("1️⃣", "연결 속도 테스트")
        start_time = time.time()
        
        for i in range(5):
            connection = db.get_connection()
            cursor = connection.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            cursor.close()
            connection.close()
        
        avg_time = (time.time() - start_time) / 5
        print(f"   ⏱️  평균 연결 시간: {avg_time:.3f}초")
        
        if avg_time < 0.1:
            print("   ✅ 연결 속도: 매우 빠름")
        elif avg_time < 0.5:
            print("   ✅ 연결 속도: 빠름")
        elif avg_time < 1.0:
            print("   ⚠️  연결 속도: 보통")
        else:
            print("   ❌ 연결 속도: 느림 (네트워크 또는 서버 확인 필요)")
        
        print_step("2️⃣", "쿼리 성능 테스트")
        connection = db.get_connection()
        cursor = connection.cursor()
        
        # 간단한 쿼리 성능 테스트
        test_queries = [
            ("SELECT COUNT(*) FROM analysis_results", "분석 결과 개수"),
            ("SELECT COUNT(*) FROM news_articles", "뉴스 기사 개수"),
            ("SELECT MAX(created_at) FROM analysis_results", "최근 분석 시간")
        ]
        
        for query, description in test_queries:
            start_time = time.time()
            cursor.execute(query)
            cursor.fetchone()
            query_time = time.time() - start_time
            print(f"   ⏱️  {description}: {query_time:.3f}초")
        
        cursor.close()
        connection.close()
        
        return True
        
    except Exception as e:
        print(f"❌ 성능 테스트 실패: {e}")
        return False

def generate_test_report():
    """테스트 결과 종합 보고서"""
    print_header("테스트 결과 종합 보고서")
    
    test_results = {}
    
    # 각 테스트 실행 및 결과 수집
    print("📋 테스트 실행 중...")
    
    test_results['requirements'] = check_mysql_requirements()
    test_results['connection'] = test_mysql_connection()
    test_results['operations'] = test_database_operations()
    test_results['performance'] = run_performance_test()
    
    # 결과 요약
    print_step("📊", "테스트 결과 요약")
    
    total_tests = len(test_results)
    passed_tests = sum(test_results.values())
    
    print(f"   전체 테스트: {total_tests}개")
    print(f"   통과한 테스트: {passed_tests}개")
    print(f"   실패한 테스트: {total_tests - passed_tests}개")
    print(f"   성공률: {(passed_tests/total_tests)*100:.1f}%")
    
    print("\n📋 상세 결과:")
    test_names = {
        'requirements': '요구사항 확인',
        'connection': 'MySQL 연결',
        'operations': '데이터베이스 작업',
        'performance': '성능 테스트'
    }
    
    for test_key, test_name in test_names.items():
        status = "✅ 통과" if test_results[test_key] else "❌ 실패"
        print(f"   {test_name}: {status}")
    
    # 권장사항
    if passed_tests == total_tests:
        print("\n🎉 모든 테스트가 성공했습니다!")
        print("   MySQL 데이터베이스가 정상적으로 설정되었습니다.")
        print("   뉴스 분석 시스템을 시작할 수 있습니다.")
    else:
        print("\n⚠️  일부 테스트가 실패했습니다.")
        print("   다음 사항을 확인해주세요:")
        
        if not test_results['requirements']:
            print("   1. 필요한 Python 패키지 설치")
            print("   2. .env 파일 설정 확인")
        
        if not test_results['connection']:
            print("   3. MySQL 서버 실행 상태 확인")
            print("   4. 연결 정보 (호스트, 포트, 사용자명, 비밀번호) 확인")
        
        if not test_results['operations']:
            print("   5. 데이터베이스 권한 확인")
            print("   6. 테이블 생성 권한 확인")
    
    return passed_tests == total_tests

def main():
    """메인 테스트 함수"""
    print("🔍 MySQL 데이터베이스 연결 테스트 도구")
    print("News Analysis System - Database Test")
    print(f"테스트 시작 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    try:
        # 종합 테스트 실행
        success = generate_test_report()
        
        if success:
            print("\n✅ 모든 테스트가 성공적으로 완료되었습니다!")
            print("🚀 이제 뉴스 분석 시스템을 실행할 수 있습니다:")
            print("   python main_system.py")
            return True
        else:
            print("\n❌ 일부 테스트가 실패했습니다.")
            print("🔧 위의 권장사항을 확인한 후 다시 테스트해주세요.")
            return False
            
    except KeyboardInterrupt:
        print("\n⏹️  테스트가 중단되었습니다.")
        return False
    except Exception as e:
        print(f"\n❌ 예상치 못한 오류: {e}")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)