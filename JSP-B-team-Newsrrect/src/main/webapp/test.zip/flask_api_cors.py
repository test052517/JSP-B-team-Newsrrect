from flask import Flask, request, jsonify
from flask_cors import CORS
import json
from datetime import datetime
import traceback
import time

# 기존 모듈들 import
from config import Config
from database import DatabaseManager
from keyword_extractor import KeywordExtractor
from news_searcher import NaverNewsSearcher
from news_analyzer import NewsAnalyzer

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

# CORS 설정 - JSP에서 호출할 수 있도록 허용
CORS(app, origins=[
    "http://localhost:8080",    # 톰캣 기본 포트
    "http://localhost:9090",    # 대체 포트
    "http://127.0.0.1:8080",
    "http://127.0.0.1:9090",
    "http://113.198.238.113:8080"
])

# 시스템 인스턴스 생성
news_system = None

def initialize_system():
    """시스템 초기화"""
    global news_system
    try:
        from main_system_modified import ModifiedNewsAnalysisSystem
        news_system = ModifiedNewsAnalysisSystem()
        print("뉴스 분석 시스템 초기화 완료")
        return True
    except Exception as e:
        print(f"시스템 초기화 실패: {e}")
        return False

@app.route('/analyze', methods=['POST', 'OPTIONS'])
def analyze_news():
    """뉴스 분석 API - JSP에서 호출"""
    
    # OPTIONS 요청 처리 (CORS preflight)
    if request.method == 'OPTIONS':
        response = jsonify({'status': 'ok'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST, OPTIONS')
        return response
    
    try:
        # JSON 또는 Form 데이터 처리
        if request.is_json:
            data = request.get_json()
        else:
            data = request.form.to_dict()
        
        if not data:
            return jsonify({
                'success': False,
                'error': '요청 데이터가 없습니다.'
            }), 400
            
        url = data.get('url', '').strip()
        text = data.get('text', '').strip()

        if not url and not text:
            return jsonify({
                'success': False,
                'error': '분석할 URL 또는 텍스트를 입력해주세요.'
            }), 400

        # URL이 우선순위를 가짐
        if url:
            if not (url.startswith('http://') or url.startswith('https://')):
                return jsonify({
                    'success': False,
                    'error': '올바른 URL 형식이 아닙니다.'
                }), 400
            
            result = news_system.analyze_news_url(url)
        else:
            result = news_system.analyze_news_text(text)

        # CORS 헤더 추가
        response = jsonify(result)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response

    except Exception as e:
        print(f"Analyze API 오류: {e}")
        traceback.print_exc()
        
        error_response = jsonify({
            'success': False,
            'error': f'서버 오류: {str(e)}'
        })
        error_response.headers.add('Access-Control-Allow-Origin', '*')
        return error_response, 500

@app.route('/history', methods=['GET'])
def get_history():
    """분석 기록 조회 API"""
    try:
        limit = request.args.get('limit', 20, type=int)
        history = news_system.db_manager.get_analysis_history(limit)
        
        response = jsonify({
            'success': True,
            'history': history
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
        
    except Exception as e:
        error_response = jsonify({
            'success': False,
            'error': f'기록 조회 오류: {str(e)}'
        })
        error_response.headers.add('Access-Control-Allow-Origin', '*')
        return error_response

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """통계 정보 API"""
    try:
        stats = news_system.db_manager.get_statistics()
        history = news_system.db_manager.get_analysis_history(10)
        
        response = jsonify({
            'success': True,
            'stats': {
                'total_analyses': stats['total_analyses'],
                'average_reliability': stats['average_reliability'],
                'reliability_distribution': stats['reliability_distribution'],
                'today_analyses': stats['today_analyses'],
                'recent_analyses': history
            }
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
        
    except Exception as e:
        error_response = jsonify({
            'success': False,
            'error': f'통계 조회 오류: {str(e)}'
        })
        error_response.headers.add('Access-Control-Allow-Origin', '*')
        return error_response

@app.route('/health', methods=['GET'])
def health_check():
    """시스템 상태 확인"""
    try:
        db_status = news_system.db_manager.test_connection()
        stats = news_system.db_manager.get_statistics()
        
        response = jsonify({
            'status': 'healthy' if db_status else 'unhealthy',
            'database': 'connected' if db_status else 'disconnected',
            'timestamp': datetime.now().isoformat(),
            'stats': stats
        })
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
        
    except Exception as e:
        error_response = jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        })
        error_response.headers.add('Access-Control-Allow-Origin', '*')
        return error_response

if __name__ == "__main__":
    import sys
    
    # 시스템 초기화
    if not initialize_system():
        print("시스템을 시작할 수 없습니다.")
        sys.exit(1)
    
    print("Flask API 서버 시작 (JSP 연동용)")
    print("CORS가 설정되어 JSP에서 호출 가능합니다.")
    print(f"API 엔드포인트: http://localhost:{Config.PORT}")
    
    try:
        app.run(
            host=Config.HOST, 
            port=Config.PORT, 
            debug=Config.DEBUG,
            threaded=True
        )
    except KeyboardInterrupt:
        print("\nAPI 서버를 종료합니다.")
    except Exception as e:
        print(f"서버 실행 오류: {e}")