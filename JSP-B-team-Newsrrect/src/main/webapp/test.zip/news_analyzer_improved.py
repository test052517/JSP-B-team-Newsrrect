import cohere
import re
from typing import List, Dict, Tuple
from datetime import datetime
from config import Config
import time

class ImprovedNewsAnalyzer:
    def __init__(self):
        try:
            self.cohere_client = cohere.Client(Config.COHERE_API_KEY)
            print(f"Cohere 클라이언트 초기화 성공 (API 키: {Config.COHERE_API_KEY[:10]}...)")
        except Exception as e:
            print(f"Cohere 클라이언트 초기화 실패: {e}")
            self.cohere_client = None
    
    def summarize_original_only(self, title: str, content: str) -> str:
        """원본 글만을 요약 (외부 뉴스 없이)"""
        if not self.cohere_client:
            return self._fallback_summary(title, content)
        
        try:
            # 텍스트 길이 제한
            full_text = f"{title}\n\n{content}"
            if len(full_text) > 3000:
                full_text = full_text[:3000] + "..."
            
            print(f"원본 요약 대상 텍스트 길이: {len(full_text)} 글자")
            
            # 원본만 요약하는 프롬프트
            prompt = f"""다음은 하나의 뉴스 기사 또는 글입니다. 이 글의 핵심 내용만을 바탕으로 3-4문장의 명확한 요약을 작성해주세요. 

중요한 규칙:
- 원문에 없는 내용은 추가하지 마세요
- 추측이나 해석은 하지 마세요  
- 사실만 간결하게 요약하세요
- 서론 없이 바로 요약 본문으로 시작하세요

원문:
{full_text}

요약:"""

            print("Cohere API로 원본 글 요약 생성 중...")
            
            models_to_try = ['command-r-plus', 'command-r', 'command']
            
            for model in models_to_try:
                try:
                    response = self.cohere_client.generate(
                        model=model,
                        prompt=prompt,
                        max_tokens=200,
                        temperature=0.2,  # 낮은 temperature로 정확성 향상
                        k=0,
                        p=0.8
                    )
                    
                    summary = response.generations[0].text.strip()
                    cleaned_summary = self._clean_summary(summary)
                    
                    if cleaned_summary and len(cleaned_summary) > 30:
                        print(f"원본 요약 생성 성공: {len(cleaned_summary)} 글자")
                        return cleaned_summary
                        
                except Exception as model_error:
                    print(f"모델 {model} 실패: {model_error}")
                    continue
            
            # 모든 모델 실패시 폴백
            return self._fallback_summary(title, content)
            
        except Exception as e:
            print(f"원본 요약 생성 오류: {e}")
            return self._fallback_summary(title, content)
    
    def cross_verify_with_related_news(self, original_title: str, original_content: str, 
                                     related_articles: List[Dict], keywords: List[str]) -> Dict:
        """원본 글과 관련 뉴스를 비교하여 팩트체킹 수행"""
        try:
            if not related_articles:
                return {
                    'reliability_score': 40.0,
                    'verification_status': 'insufficient_data',
                    'verification_details': '팩트체킹을 위한 관련 뉴스가 부족합니다.',
                    'cross_check_points': [],
                    'consistency_analysis': '비교 분석을 수행할 수 없습니다.'
                }
            
            # 1. 기본 신뢰성 점수 계산
            basic_score = self._calculate_basic_reliability(original_content, related_articles, keywords)
            
            # 2. AI를 이용한 교차검증 (가능한 경우)
            ai_verification = self._ai_cross_verification(
                original_title, original_content, related_articles[:3]
            )
            
            # 3. 최종 신뢰성 점수 결정
            final_score = self._combine_scores(basic_score, ai_verification.get('ai_score', basic_score))
            
            # 4. 검증 상태 결정
            verification_status = self._determine_verification_status(final_score, len(related_articles))
            
            # 5. 상세 분석 생성
            verification_details = self._generate_detailed_verification(
                original_title, related_articles, final_score, verification_status
            )
            
            return {
                'reliability_score': final_score,
                'verification_status': verification_status,
                'verification_details': verification_details,
                'cross_check_points': ai_verification.get('check_points', []),
                'consistency_analysis': ai_verification.get('consistency_analysis', ''),
                'related_articles_count': len(related_articles)
            }
            
        except Exception as e:
            print(f"교차검증 오류: {e}")
            return {
                'reliability_score': 50.0,
                'verification_status': 'error',
                'verification_details': f'팩트체킹 중 오류 발생: {str(e)}',
                'cross_check_points': [],
                'consistency_analysis': '분석 중 오류가 발생했습니다.'
            }
    
    def _ai_cross_verification(self, title: str, content: str, articles: List[Dict]) -> Dict:
        """AI를 이용한 교차검증"""
        if not self.cohere_client or not articles:
            return {'ai_score': 50.0, 'check_points': [], 'consistency_analysis': 'AI 분석 불가'}
        
        try:
            # 관련 기사들 요약
            related_summary = self._summarize_related_articles(articles)
            
            # 교차검증 프롬프트
            verification_prompt = f"""다음 원본 글과 관련 뉴스들을 비교분석해주세요.

원본 글:
제목: {title}
내용: {content[:1000]}

관련 뉴스:
{related_summary}

다음 기준으로 분석해주세요:
1. 핵심 사실들이 일치하는가?
2. 상충되는 정보가 있는가?
3. 원본 글의 신뢰성은 어느 정도인가?

신뢰성 점수 (0-100점)와 간단한 분석을 제공해주세요."""

            response = self.cohere_client.generate(
                model='command-r-plus',
                prompt=verification_prompt,
                max_tokens=300,
                temperature=0.3
            )
            
            analysis_text = response.generations[0].text.strip()
            
            # AI 점수 추출
            ai_score = self._extract_score_from_text(analysis_text)
            
            # 주요 검증 포인트 추출
            check_points = self._extract_check_points(analysis_text)
            
            return {
                'ai_score': ai_score,
                'check_points': check_points,
                'consistency_analysis': analysis_text
            }
            
        except Exception as e:
            print(f"AI 교차검증 오류: {e}")
            return {
                'ai_score': 50.0,
                'check_points': [],
                'consistency_analysis': f'AI 분석 실패: {str(e)}'
            }
    
    def _calculate_basic_reliability(self, content: str, articles: List[Dict], keywords: List[str]) -> float:
        """기본 신뢰성 점수 계산"""
        score = 20.0
        
        # 관련 기사 수에 따른 점수
        article_count = len(articles)
        if article_count >= 5:
            score += 25
        elif article_count >= 3:
            score += 20
        elif article_count >= 1:
            score += 10
        
        # 키워드 일치도
        content_lower = content.lower()
        keyword_matches = 0
        
        for article in articles:
            title = article.get('title', '').lower()
            description = article.get('description', '').lower()
            
            for keyword in keywords:
                keyword_lower = keyword.lower()
                if (keyword_lower in content_lower and 
                    (keyword_lower in title or keyword_lower in description)):
                    keyword_matches += 1
        
        # 키워드 매칭 점수
        if keywords and article_count > 0:
            match_ratio = keyword_matches / (len(keywords) * article_count)
            score += match_ratio * 20
        
        # 언론사 기사 가산점
        press_articles = sum(1 for article in articles if article.get('is_press', False))
        if article_count > 0:
            press_ratio = press_articles / article_count
            score += press_ratio * 15
        
        # 최근성 가산점
        recent_articles = sum(1 for article in articles 
                            if '2024' in article.get('pub_date', '') or '2025' in article.get('pub_date', ''))
        if article_count > 0:
            recent_ratio = recent_articles / article_count
            score += recent_ratio * 10
        
        return min(100.0, max(0.0, score))
    
    def _summarize_related_articles(self, articles: List[Dict]) -> str:
        """관련 기사들을 간단히 요약"""
        summaries = []
        for i, article in enumerate(articles[:3], 1):
            title = article.get('title', '')[:100]
            source = article.get('bloggername', '') or article.get('domain', '')
            summaries.append(f"기사 {i}: {title} (출처: {source})")
        
        return "\n".join(summaries)
    
    def _extract_score_from_text(self, text: str) -> float:
        """텍스트에서 점수 추출"""
        patterns = [
            r'신뢰성.*?(\d+(?:\.\d+)?)점',
            r'점수.*?(\d+(?:\.\d+)?)',
            r'(\d+(?:\.\d+)?)점',
            r'(\d+(?:\.\d+)?)%'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                score = float(match.group(1))
                return min(100.0, max(0.0, score))
        
        # 텍스트 분석으로 점수 추정
        return self._estimate_score_from_keywords(text)
    
    def _estimate_score_from_keywords(self, text: str) -> float:
        """키워드 분석으로 점수 추정"""
        text_lower = text.lower()
        
        positive_keywords = ['일치', '확인', '신뢰', '정확', '사실', '검증됨', '맞음']
        negative_keywords = ['모순', '불일치', '의심', '거짓', '불확실', '틀림', '문제']
        
        positive_count = sum(1 for keyword in positive_keywords if keyword in text_lower)
        negative_count = sum(1 for keyword in negative_keywords if keyword in text_lower)
        
        base_score = 60.0
        score_adjustment = (positive_count * 10) - (negative_count * 15)
        
        return max(0.0, min(100.0, base_score + score_adjustment))
    
    def _extract_check_points(self, text: str) -> List[str]:
        """분석 텍스트에서 주요 검증 포인트 추출"""
        check_points = []
        
        # 간단한 규칙 기반 추출
        sentences = text.split('.')
        for sentence in sentences:
            sentence = sentence.strip()
            if any(keyword in sentence for keyword in ['일치', '확인', '검증', '사실', '문제', '의심']):
                if len(sentence) > 10:
                    check_points.append(sentence)
        
        return check_points[:3]  # 최대 3개만 반환
    
    def _combine_scores(self, basic_score: float, ai_score: float) -> float:
        """기본 점수와 AI 점수를 결합"""
        # 가중평균 (기본 점수 60%, AI 점수 40%)
        combined = (basic_score * 0.6) + (ai_score * 0.4)
        return round(combined, 1)
    
    def _determine_verification_status(self, score: float, article_count: int) -> str:
        """점수와 기사 수를 바탕으로 검증 상태 결정"""
        if score >= 80 and article_count >= 3:
            return 'high_confidence'
        elif score >= 60 and article_count >= 2:
            return 'medium_confidence'
        elif score >= 40 and article_count >= 1:
            return 'low_confidence'
        else:
            return 'insufficient_verification'
    
    def _generate_detailed_verification(self, title: str, articles: List[Dict], 
                                      score: float, status: str) -> str:
        """상세한 검증 결과 생성"""
        details = [f"분석 대상: {title}", f"신뢰성 점수: {score}점"]
        
        # 상태별 메시지
        status_messages = {
            'high_confidence': '높은 신뢰도: 여러 관련 뉴스에서 내용이 확인됩니다.',
            'medium_confidence': '중간 신뢰도: 일부 관련 뉴스에서 내용이 확인됩니다.',
            'low_confidence': '낮은 신뢰도: 관련 정보가 제한적입니다.',
            'insufficient_verification': '검증 부족: 충분한 관련 뉴스를 찾을 수 없습니다.'
        }
        
        details.append(status_messages.get(status, '알 수 없는 상태'))
        details.append(f"관련 뉴스: {len(articles)}건 분석")
        
        # 언론사 기사 정보
        press_count = sum(1 for article in articles if article.get('is_press', False))
        if press_count > 0:
            details.append(f"주요 언론사 보도: {press_count}건")
        
        return " | ".join(details)
    
    def _fallback_summary(self, title: str, content: str) -> str:
        """AI 없이 기본 요약 생성"""
        if not content.strip():
            return "요약할 내용이 없습니다."
        
        # 첫 250자를 기본으로, 완전한 문장까지만
        summary_length = min(250, len(content))
        summary = content[:summary_length]
        
        # 마지막 완전한 문장까지만 포함
        sentences = summary.split('.')
        if len(sentences) > 1:
            complete_sentences = sentences[:-1]
            summary = '. '.join(complete_sentences) + '.'
        
        if len(summary.strip()) < 20:
            summary = content[:100] + "..."
        
        return summary.strip()
    
    def _clean_summary(self, summary: str) -> str:
        """요약 텍스트 정리"""
        # 불필요한 접두사 제거
        prefixes = [
            "요약:", "간단 요약:", "[요약]", "핵심 요약:", 
            "다음은 요약입니다:", "내용을 요약하면:"
        ]
        
        for prefix in prefixes:
            if summary.startswith(prefix):
                summary = summary[len(prefix):].strip()
        
        # 연속 공백 정리
        summary = re.sub(r'\s+', ' ', summary)
        
        return summary.strip()
    
    def generate_comprehensive_report(self, title: str, content: str, keywords: List[str], 
                                    related_articles: List[Dict]) -> Dict:
        """종합 분석 보고서 생성 (요약 + 팩트체킹)"""
        try:
            print("종합 분석 보고서 생성 시작...")
            
            # 1. 원본 글만 요약
            print("1. 원본 글 요약 생성...")
            original_summary = self.summarize_original_only(title, content)
            
            # 2. 팩트체킹 수행
            print("2. 팩트체킹 수행...")
            fact_check_result = self.cross_verify_with_related_news(
                title, content, related_articles, keywords
            )
            
            # 3. 관련 기사 정보 정리
            articles_info = []
            for article in related_articles:
                articles_info.append({
                    'title': article.get('title', ''),
                    'source': (article.get('bloggername', '') or 
                              article.get('source', '') or 
                              article.get('domain', '')),
                    'pub_date': article.get('pub_date', ''),
                    'url': article.get('link', '') or article.get('url', ''),
                    'relevance_score': article.get('relevance_score', 0)
                })
            
            report = {
                'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'original_title': title,
                'keywords': keywords,
                'original_summary': original_summary,  # 원본 글만의 요약
                'fact_check': fact_check_result,       # 팩트체킹 결과
                'articles_analyzed': len(related_articles),
                'articles_info': articles_info
            }
            
            print("종합 분석 보고서 생성 완료")
            return {'success': True, 'report': report}
            
        except Exception as e:
            error_msg = f'종합 보고서 생성 오류: {str(e)}'
            print(error_msg)
            return {'success': False, 'error': error_msg}