import requests
import cohere
from bs4 import BeautifulSoup
import re
from typing import List, Dict, Optional
from urllib.parse import urlparse
from config import Config
import time

class KeywordExtractor:
    def __init__(self):
        self.cohere_client = cohere.Client(Config.COHERE_API_KEY)
    
    def extract_content_from_url(self, url: str) -> Dict[str, str]:
        """URL에서 뉴스 내용 추출"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            response.encoding = response.apparent_encoding
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 메타데이터 추출
            title = self._extract_title(soup)
            content = self._extract_content(soup)
            
            return {
                'title': title,
                'content': content,
                'url': url,
                'domain': urlparse(url).netloc
            }
            
        except requests.RequestException as e:
            print(f"URL 접근 오류: {e}")
            return {'title': '', 'content': '', 'url': url, 'domain': ''}
        except Exception as e:
            print(f"콘텐츠 추출 오류: {e}")
            return {'title': '', 'content': '', 'url': url, 'domain': ''}
    
    def _extract_title(self, soup: BeautifulSoup) -> str:
        """제목 추출"""
        title_selectors = [
            'h1.headline',
            'h1.title',
            '.article-title h1',
            '.news-title',
            'h1',
            'title'
        ]
        
        for selector in title_selectors:
            title_element = soup.select_one(selector)
            if title_element:
                title = title_element.get_text(strip=True)
                if len(title) > 10:
                    return self._clean_text(title)
        
        return ""
    
    def _extract_content(self, soup: BeautifulSoup) -> str:
        """본문 내용 추출"""
        # 불필요한 요소 제거
        for element in soup(['script', 'style', 'nav', 'header', 'footer', 'aside']):
            element.decompose()
        
        content_selectors = [
            'article',
            '.article-body',
            '.article-content',
            '.news-content',
            '.content',
            '#articleBodyContents',
            '.article_body',
            '.view-content',
            '.post-content'
        ]
        
        for selector in content_selectors:
            content_element = soup.select_one(selector)
            if content_element:
                content = content_element.get_text(strip=True)
                if len(content) > 100:
                    return self._clean_text(content)
        
        # 대안: 모든 p 태그에서 내용 추출
        paragraphs = soup.find_all('p')
        content = ' '.join([p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 20])
        
        return self._clean_text(content)
    
    def _clean_text(self, text: str) -> str:
        """텍스트 정리"""
        # HTML 태그 제거
        text = re.sub(r'<[^>]+>', '', text)
        # 연속된 공백 정리
        text = re.sub(r'\s+', ' ', text)
        # 특수문자 정리
        text = re.sub(r'[^\w\s가-힣.,!?;:]', ' ', text)
        return text.strip()
    
    def extract_keywords_with_cohere(self, text: str, num_keywords: int = 8) -> List[str]:
        """Cohere API를 사용한 키워드 추출"""
        try:
            # 텍스트가 너무 길면 앞부분만 사용
            if len(text) > 3000:
                text = text[:3000] + "..."
            
            prompt = f"""다음 한국어 뉴스에서 중요한 키워드 {num_keywords}개를 추출해주세요.
키워드는 쉼표로 구분하여 나열해주세요.

뉴스 내용:
{text}

키워드:"""
            
            # 여러 모델 시도
            models_to_try = ['command-r-plus', 'command-r', 'command']
            
            for model in models_to_try:
                try:
                    print(f"모델 {model}로 키워드 추출 시도...")
                    
                    response = self.cohere_client.generate(
                        model=model,
                        prompt=prompt,
                        max_tokens=100,
                        temperature=0.3,
                        k=0,
                        p=0.9
                    )
                    
                    keywords_text = response.generations[0].text.strip()
                    keywords = self._parse_keywords(keywords_text, num_keywords)
                    
                    if keywords:
                        print(f"키워드 추출 성공: {keywords}")
                        return keywords
                        
                except Exception as model_error:
                    print(f"모델 {model} 실패: {model_error}")
                    continue
            
            # 모든 모델 실패시 폴백
            print("모든 Cohere 모델 실패, 폴백 방식 사용")
            return self._fallback_keyword_extraction(text, num_keywords)
            
        except Exception as e:
            print(f"Cohere 키워드 추출 오류: {e}")
            return self._fallback_keyword_extraction(text, num_keywords)
    
    def _parse_keywords(self, keywords_text: str, max_count: int) -> List[str]:
        """키워드 텍스트 파싱"""
        # 쉼표, 세미콜론, 줄바꿈으로 분리
        keywords = re.split(r'[,;\\n]', keywords_text)
        
        parsed_keywords = []
        for keyword in keywords:
            # 숫자나 특수기호 제거하고 정리
            cleaned = re.sub(r'^\d+\.?\s*', '', keyword.strip())
            cleaned = re.sub(r'[^\w가-힣\s-]', '', cleaned).strip()
            
            if len(cleaned) >= 2 and len(cleaned) <= 20:
                parsed_keywords.append(cleaned)
        
        # 중복 제거하고 최대 개수만큼 반환
        unique_keywords = list(dict.fromkeys(parsed_keywords))
        return unique_keywords[:max_count]
    
    def _fallback_keyword_extraction(self, text: str, num_keywords: int) -> List[str]:
        """Cohere API 실패시 대안 키워드 추출"""
        from collections import Counter
        import re
        
        print("폴백 키워드 추출 방식 사용")
        
        # 한글 명사 패턴 추출 (간단한 방식)
        korean_words = re.findall(r'[가-힣]{2,10}', text)
        
        # 불용어 제거
        stopwords = {'것이', '그것', '이것', '저것', '때문', '경우', '때문에', '통해', '위해', '대해', '관련', '의해', '에서', '에게', '에는', '에도', '에만'}
        
        filtered_words = [word for word in korean_words if word not in stopwords and len(word) >= 2]
        
        # 빈도 계산 후 상위 키워드 추출
        word_freq = Counter(filtered_words)
        return [word for word, freq in word_freq.most_common(num_keywords)]
    
    def extract_keywords_from_url(self, url: str, num_keywords: int = None) -> Dict:
        """URL에서 키워드 추출 (메인 함수)"""
        if num_keywords is None:
            num_keywords = Config.KEYWORD_COUNT
        
        # 1. 콘텐츠 추출
        print(f"URL에서 콘텐츠 추출: {url}")
        content_data = self.extract_content_from_url(url)
        
        if not content_data['title'] and not content_data['content']:
            return {
                'success': False,
                'error': '콘텐츠를 추출할 수 없습니다.',
                'keywords': [],
                'content_data': content_data
            }
        
        # 2. 키워드 추출
        full_text = f"{content_data['title']} {content_data['content']}"
        print(f"키워드 추출 시작 (텍스트 길이: {len(full_text)})")
        
        keywords = self.extract_keywords_with_cohere(full_text, num_keywords)
        
        if not keywords:
            print("키워드 추출 실패, 기본 키워드 사용")
            keywords = ["뉴스", "분석", "정보"]
        
        return {
            'success': True,
            'keywords': keywords,
            'content_data': content_data,
            'full_text': full_text[:500] + "..." if len(full_text) > 500 else full_text
        }

# 테스트 함수
def test_keyword_extraction():
    """키워드 추출 테스트"""
    extractor = KeywordExtractor()
    
    test_url = input("테스트할 뉴스 URL을 입력하세요: ")
    result = extractor.extract_keywords_from_url(test_url)
    
    if result['success']:
        print(f"제목: {result['content_data']['title']}")
        print(f"키워드: {', '.join(result['keywords'])}")
        print(f"본문 미리보기: {result['full_text'][:200]}...")
    else:
        print(f"오류: {result['error']}")

if __name__ == "__main__":
    test_keyword_extraction()