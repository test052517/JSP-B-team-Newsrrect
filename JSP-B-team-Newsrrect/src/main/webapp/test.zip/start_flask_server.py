#!/usr/bin/env python3
"""
Flask API 서버 시작 스크립트
JSP와 연동하기 위한 뉴스 분석 API 서버를 시작합니다.
"""

import sys
import os
import subprocess
import time
import requests
from datetime import datetime

def check_port_available(port=5000):
    """포트 사용 가능 여부 확인"""
    try:
        response = requests.get(f"http://localhost:{port}/health", timeout=2)
        return False  # 이미 사용 중
    except:
        return True   # 사용 가능

def start_flask_server():
    """Flask API 서버 시작"""
    print("=" * 60)
    print("뉴스 분석 시스템 Flask API 서버 시작")
    print("=" * 60)
    print(f"시작 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 포트 확인
    if not check_port_available():
        print("✅ Flask 서버가 이미 실행 중입니다 (포트 5000)")
        return True
    
    print("🚀 Flask API 서버를 시작합니다...")
    
    try:
        # flask_api_cors.py 파일이 있는지 확인
        if os.path.exists('flask_api_cors.py'):
            print("📁 flask_api_cors.py 파일 발견")
            subprocess.Popen([sys.executable, 'flask_api_cors.py'])
        elif os.path.exists('main_system_modified.py'):
            print("📁 main_system_modified.py 파일 발견")
            subprocess.Popen([sys.executable, 'main_system_modified.py'])
        elif os.path.exists('main_system.py'):
            print("📁 main_system.py 파일 발견")
            subprocess.Popen([sys.executable, 'main_system.py'])
        else:
            print("❌ Flask 서버 파일을 찾을 수 없습니다.")
            print("다음 파일 중 하나가 필요합니다:")
            print("- flask_api_cors.py")
            print("- main_system_modified.py")
            print("- main_system.py")
            return False
        
        # 서버 시작 대기
        print("⏳ 서버 시작을 기다리는 중...")
        for i in range(10):
            time.sleep(2)
            if not check_port_available():
                print("✅ Flask API 서버가 성공적으로 시작되었습니다!")
                print("🌐 API 엔드포인트:")
                print("   - http://localhost:5000/analyze")
                print("   - http://localhost:5000/api/stats")
                print("   - http://localhost:5000/health")
                return True
            print(f"   시도 {i+1}/10...")
        
        print("❌ 서버 시작에 실패했습니다.")
        return False
        
    except Exception as e:
        print(f"❌ 서버 시작 중 오류 발생: {e}")
        return False

def test_api_connection():
    """API 연결 테스트"""
    print("\n" + "=" * 60)
    print("API 연결 테스트")
    print("=" * 60)
    
    endpoints = [
        ("헬스체크", "http://localhost:5000/health"),
        ("통계 조회", "http://localhost:5000/api/stats"),
    ]
    
    for name, url in endpoints:
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                print(f"✅ {name}: 정상 ({response.status_code})")
            else:
                print(f"⚠️ {name}: 응답 코드 {response.status_code}")
        except Exception as e:
            print(f"❌ {name}: 연결 실패 - {str(e)}")
    
    # 분석 API 테스트 (POST)
    try:
        test_data = {"text": "테스트 텍스트입니다. API 연결을 확인하고 있습니다."}
        response = requests.post(
            "http://localhost:5000/analyze", 
            json=test_data, 
            timeout=10
        )
        if response.status_code == 200:
            print("✅ 분석 API: 정상 (POST)")
        else:
            print(f"⚠️ 분석 API: 응답 코드 {response.status_code}")
    except Exception as e:
        print(f"❌ 분석 API: 연결 실패 - {str(e)}")

def show_usage_instructions():
    """사용 방법 안내"""
    print("\n" + "=" * 60)
    print("사용 방법")
    print("=" * 60)
    print("1. 톰캣 서버가 실행되고 있는지 확인하세요")
    print("2. 브라우저에서 JSP 페이지에 접속하세요:")
    print("   http://localhost:8080/your-project/news_analysis.jsp")
    print("")
    print("3. JSP에서 다음 URL로 API를 호출합니다:")
    print("   - 분석: POST http://localhost:5000/analyze")
    print("   - 통계: GET http://localhost:5000/api/stats")
    print("")
    print("4. Flask 서버를 중지하려면:")
    print("   - 이 터미널에서 Ctrl+C")
    print("   - 또는 프로세스 매니저에서 Python 프로세스 종료")

def main():
    """메인 함수"""
    print("뉴스 분석 시스템 - Flask API 서버 관리 도구")
    
    # 서버 시작
    if start_flask_server():
        # 연결 테스트
        test_api_connection()
        
        # 사용 방법 안내
        show_usage_instructions()
        
        print("\n✅ Flask API 서버가 정상적으로 실행 중입니다.")
        print("❗ JSP에서 API를 호출할 수 있습니다.")
        
        # 서버 상태 모니터링
        print("\n🔍 서버 상태 모니터링 중... (Ctrl+C로 종료)")
        try:
            while True:
                time.sleep(30)  # 30초마다 체크
                if check_port_available():
                    print(f"❌ {datetime.now().strftime('%H:%M:%S')} - 서버가 중지되었습니다!")
                    break
                else:
                    print(f"✅ {datetime.now().strftime('%H:%M:%S')} - 서버 정상 작동 중")
        except KeyboardInterrupt:
            print("\n👋 모니터링을 종료합니다.")
    
    else:
        print("\n❌ Flask API 서버 시작에 실패했습니다.")
        print("📋 문제 해결 방법:")
        print("1. 필요한 Python 패키지가 설치되어 있는지 확인")
        print("   pip install flask flask-cors requests")
        print("2. 데이터베이스 연결이 정상인지 확인")
        print("3. 환경변수(.env)가 올바르게 설정되어 있는지 확인")
        print("4. 포트 5000이 다른 프로그램에서 사용 중이 아닌지 확인")

if __name__ == "__main__":
    main()