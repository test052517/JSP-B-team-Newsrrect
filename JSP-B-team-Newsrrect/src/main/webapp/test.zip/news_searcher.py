import requests
import re
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from config import Config
import time
import urllib.parse

class NaverNewsSearcher:
    def __init__(self):
        self.client_id = Config.NAVER_CLIENT_ID
        self.client_secret = Config.NAVER_CLIENT_SECRET
        self.base_url = "https://openapi.naver.com/v1/search/news.json"
    
    def search_news(self, keywords: List[str], count: int = None, sort: str = "sim") -> Dict:
        """네이버 뉴스 API로 뉴스 검색"""
        if count is None:
            count = Config.MAX_NEWS_COUNT
        
        try:
            # 키워드 조합 (최대 3개 주요 키워드 사용)
            query = self._build_query(keywords[:3])
            
            headers = {
                "X-Naver-Client-Id": self.client_id,
                "X-Naver-Client-Secret": self.client_secret
            }
            
            params = {
                "query": query,
                "display": min(count, 100),  # 네이버 API 최대 100개
                "start": 1,
                "sort": sort  # sim(유사도순), date(날짜순)
            }
            
            response = requests.get(self.base_url, headers=headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            
            # 결과 처리
            articles = self._process_articles(data.get('items', []))
            
            return {
                'success': True,
                'total_count': data.get('total', 0),
                'articles': articles,
                'query': query,
                'search_params': params
            }
            
        except requests.RequestException as e:
            return {
                'success': False,
                'error': f'네이버 API 요청 오류: {str(e)}',
                'articles': [],
                'query': query if 'query' in locals() else ''
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'검색 처리 오류: {str(e)}',
                'articles': [],
                'query': ''
            }
    
    def _build_query(self, keywords: List[str]) -> str:
        """검색 쿼리 생성"""
        if not keywords:
            return ""
        
        # 키워드 정리 및 조합
        cleaned_keywords = []
        for keyword in keywords:
            # 특수문자 제거, 공백 정리
            cleaned = re.sub(r'[^\w가-힣\s-]', '', keyword.strip())
            if len(cleaned) >= 2:
                cleaned_keywords.append(cleaned)
        
        if not cleaned_keywords:
            return ""
        
        # 키워드를 AND 조건으로 연결 (따옴표로 묶어서 정확도 향상)
        query_parts = []
        for keyword in cleaned_keywords[:3]:  # 최대 3개만 사용
            if ' ' in keyword:
                query_parts.append(f'"{keyword}"')
            else:
                query_parts.append(keyword)
        
        return ' '.join(query_parts)
    
    def _process_articles(self, raw_articles: List[Dict]) -> List[Dict]:
        """검색 결과 기사 처리"""
        processed_articles = []
        
        for article in raw_articles:
            processed = {
                'title': self._clean_html_tags(article.get('title', '')),
                'description': self._clean_html_tags(article.get('description', '')),
                'link': article.get('link', ''),
                'originallink': article.get('originallink', ''),
                'pub_date': self._parse_date(article.get('pubDate', '')),
                'bloggername': self._clean_html_tags(article.get('bloggername', '')),
                'bloggerlink': article.get('bloggerlink', ''),
                'is_press': self._is_press_article(article.get('link', '')),
                'domain': self._extract_domain(article.get('link', ''))
            }
            
            # 유효한 기사만 추가 (제목과 설명이 모두 있는 경우)
            if processed['title'] and processed['description']:
                processed_articles.append(processed)
        
        return processed_articles
    
    def _clean_html_tags(self, text: str) -> str:
        """HTML 태그 및 특수문자 정리"""
        if not text:
            return ""
        
        # HTML 태그 제거
        text = re.sub(r'<[^>]+>', '', text)
        # HTML 엔티티 디코딩
        text = text.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
        text = text.replace('&quot;', '"').replace('&#39;', "'").replace('&nbsp;', ' ')
        # 연속된 공백 정리
        text = re.sub(r'\s+', ' ', text.strip())
        
        return text
    
    def _parse_date(self, date_str: str) -> str:
        """날짜 문자열 파싱"""
        if not date_str:
            return ""
        
        try:
            # RFC 2822 형식 파싱 (예: "Mon, 01 Jan 2024 09:00:00 +0900")
            from email.utils import parsedate_to_datetime
            dt = parsedate_to_datetime(date_str)
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        except:
            return date_str
    
    def _is_press_article(self, url: str) -> bool:
        """언론사 기사인지 확인"""
        press_domains = [
            'news.naver.com', 'news.joins.com', 'news.chosun.com',
            'news.donga.com', 'news.hankyung.com', 'news.mk.co.kr',
            'yna.co.kr', 'newsis.com', 'ytn.co.kr'
        ]
        
        domain = self._extract_domain(url)
        return any(press_domain in domain for press_domain in press_domains)
    
    def _extract_domain(self, url: str) -> str:
        """URL에서 도메인 추출"""
        try:
            from urllib.parse import urlparse
            return urlparse(url).netloc.lower()
        except:
            return ""
    
    def search_multiple_queries(self, keywords_list: List[List[str]], count_per_query: int = 5) -> Dict:
        """여러 키워드 조합으로 검색"""
        all_articles = []
        search_results = []
        
        for keywords in keywords_list:
            result = self.search_news(keywords, count_per_query)
            search_results.append(result)
            
            if result['success']:
                all_articles.extend(result['articles'])
            
            # API 호출 간격 (네이버 API 제한 고려)
            time.sleep(0.1)
        
        # 중복 제거 (URL 기준)
        unique_articles = []
        seen_urls = set()
        
        for article in all_articles:
            url = article.get('originallink') or article.get('link')
            if url and url not in seen_urls:
                seen_urls.add(url)
                unique_articles.append(article)
        
        return {
            'success': True,
            'total_articles': len(unique_articles),
            'articles': unique_articles,
            'search_results': search_results
        }
    
    def filter_articles_by_date(self, articles: List[Dict], days_back: int = 7) -> List[Dict]:
        """날짜로 기사 필터링"""
        cutoff_date = datetime.now() - timedelta(days=days_back)
        filtered_articles = []
        
        for article in articles:
            pub_date_str = article.get('pub_date', '')
            if pub_date_str:
                try:
                    pub_date = datetime.strptime(pub_date_str, '%Y-%m-%d %H:%M:%S')
                    if pub_date >= cutoff_date:
                        filtered_articles.append(article)
                except:
                    # 날짜 파싱 실패시 포함
                    filtered_articles.append(article)
            else:
                # 날짜 정보 없는 경우 포함
                filtered_articles.append(article)
        
        return filtered_articles
    
    def rank_articles_by_relevance(self, articles: List[Dict], keywords: List[str]) -> List[Dict]:
        """키워드 관련성으로 기사 순위 매기기"""
        for article in articles:
            score = 0
            title = article.get('title', '').lower()
            description = article.get('description', '').lower()
            
            for keyword in keywords:
                keyword_lower = keyword.lower()
                # 제목에 키워드 포함시 높은 점수
                if keyword_lower in title:
                    score += 3
                # 설명에 키워드 포함시 낮은 점수
                if keyword_lower in description:
                    score += 1
            
            # 언론사 기사에 가산점
            if article.get('is_press', False):
                score += 2
            
            article['relevance_score'] = score
        
        # 관련성 점수로 정렬
        return sorted(articles, key=lambda x: x.get('relevance_score', 0), reverse=True)
    
    def get_top_articles(self, keywords: List[str], max_articles: int = None) -> Dict:
        """키워드 기반 상위 기사 검색 (통합 함수)"""
        if max_articles is None:
            max_articles = Config.MAX_NEWS_COUNT
        
        # 1. 기본 검색
        search_result = self.search_news(keywords, max_articles * 2)  # 여유있게 검색
        
        if not search_result['success']:
            return search_result
        
        articles = search_result['articles']
        
        # 2. 최근 기사만 필터링 (7일 이내)
        recent_articles = self.filter_articles_by_date(articles, days_back=7)
        
        # 3. 관련성으로 순위 매기기
        ranked_articles = self.rank_articles_by_relevance(recent_articles, keywords)
        
        # 4. 상위 기사만 선택
        top_articles = ranked_articles[:max_articles]
        
        return {
            'success': True,
            'query': search_result['query'],
            'total_found': len(articles),
            'recent_articles': len(recent_articles),
            'top_articles': top_articles,
            'search_summary': {
                'keywords': keywords,
                'search_query': search_result['query'],
                'articles_found': len(articles),
                'recent_filtered': len(recent_articles),
                'final_selected': len(top_articles)
            }
        }

# 테스트 함수
def test_news_search():
    """뉴스 검색 테스트"""
    searcher = NaverNewsSearcher()
    
    test_keywords = input("테스트할 키워드들을 쉼표로 구분해서 입력하세요: ").split(',')
    test_keywords = [k.strip() for k in test_keywords if k.strip()]
    
    result = searcher.get_top_articles(test_keywords, 5)
    
    if result['success']:
        print(f"\n검색 결과:")
        print(f"검색어: {result['query']}")
        print(f"총 발견: {result['total_found']}건")
        print(f"최근 기사: {result['recent_articles']}건")
        print(f"선별된 기사: {len(result['top_articles'])}건\n")
        
        for i, article in enumerate(result['top_articles'], 1):
            print(f"{i}. {article['title']}")
            print(f"   출처: {article['bloggername'] or article['domain']}")
            print(f"   날짜: {article['pub_date']}")
            print(f"   관련성: {article.get('relevance_score', 0)}점")
            print(f"   URL: {article['link']}")
            print()
    else:
        print(f"검색 실패: {result['error']}")

if __name__ == "__main__":
    test_news_search()