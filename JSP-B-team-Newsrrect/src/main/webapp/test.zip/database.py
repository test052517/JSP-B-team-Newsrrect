import mysql.connector
from mysql.connector import Error
import pymysql
from datetime import datetime
from typing import List, Dict, Optional
from config import Config
import time
import re

class DatabaseManager:
    def __init__(self):
        self.config = {
            'host': Config.MYSQL_HOST,
            'port': Config.MYSQL_PORT,
            'user': Config.MYSQL_USER,
            'password': Config.MYSQL_PASSWORD,
            'database': Config.MYSQL_DATABASE,
            'charset': Config.MYSQL_CHARSET,
            'autocommit': True
        }
        self.init_database()
    
    def get_connection(self):
        """MySQL 연결 생성"""
        try:
            connection = mysql.connector.connect(**self.config)
            return connection
        except Error as e:
            print(f"MySQL 연결 오류: {e}")
            # PyMySQL을 대안으로 시도
            try:
                connection = pymysql.connect(
                    host=Config.MYSQL_HOST,
                    port=Config.MYSQL_PORT,
                    user=Config.MYSQL_USER,
                    password=Config.MYSQL_PASSWORD,
                    database=Config.MYSQL_DATABASE,
                    charset=Config.MYSQL_CHARSET,
                    autocommit=True
                )
                return connection
            except Exception as e2:
                print(f"PyMySQL 연결도 실패: {e2}")
                raise e2
    
    def init_database(self):
        """데이터베이스 및 테이블 초기화"""
        try:
            # 먼저 데이터베이스 생성 (없으면)
            self.create_database()
            
            connection = self.get_connection()
            cursor = connection.cursor()
            
            # 뉴스 기사 테이블
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS news_articles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title TEXT NOT NULL,
                content TEXT,
                url VARCHAR(1000) UNIQUE,
                published_date VARCHAR(50),
                source VARCHAR(200),
                view_count INT DEFAULT 0,
                keywords TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_keywords (keywords(100)),
                INDEX idx_created_at (created_at),
                INDEX idx_url (url(200))
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # 분석 결과 테이블
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS analysis_results (
                id INT AUTO_INCREMENT PRIMARY KEY,
                original_url VARCHAR(1000) NOT NULL,
                extracted_keywords TEXT,
                related_articles_count INT,
                summary TEXT,
                reliability_score DECIMAL(5,2),
                analysis_details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_original_url (original_url(200)),
                INDEX idx_created_at (created_at),
                INDEX idx_reliability_score (reliability_score)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            # 키워드 추출 로그 테이블
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS keyword_extractions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                source_url VARCHAR(1000) NOT NULL,
                extracted_keywords TEXT,
                extraction_method VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_source_url (source_url(200)),
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ''')
            
            cursor.close()
            connection.close()
            print("데이터베이스 테이블 초기화 완료")
            
        except Exception as e:
            print(f"데이터베이스 초기화 오류: {e}")
    
    def create_database(self):
        """데이터베이스 생성"""
        try:
            # 데이터베이스 없이 연결
            temp_config = self.config.copy()
            del temp_config['database']
            
            connection = mysql.connector.connect(**temp_config)
            cursor = connection.cursor()
            
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.MYSQL_DATABASE} "
                         f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            
            cursor.close()
            connection.close()
            
        except Exception as e:
            print(f"데이터베이스 생성 오류: {e}")
    
    def save_news_articles(self, articles: List[Dict], keywords: List[str]) -> int:
        """뉴스 기사들을 데이터베이스에 저장"""
        if not articles:
            return 0
            
        connection = None
        try:
            connection = self.get_connection()
            cursor = connection.cursor()
            
            saved_count = 0
            keywords_str = ','.join(keywords)
            
            for article in articles:
                try:
                    # HTML 태그 제거 및 텍스트 정리
                    title = self._clean_text(article.get('title', ''))
                    description = self._clean_text(article.get('description', ''))
                    url = article.get('link', '') or article.get('originallink', '')
                    pub_date = article.get('pub_date', '')
                    source = self._clean_text(article.get('bloggername', ''))
                    
                    if not title or not url:
                        continue
                    
                    # 중복 확인 후 삽입
                    cursor.execute('''
                    INSERT IGNORE INTO news_articles 
                    (title, content, url, published_date, source, keywords)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ''', (title, description, url, pub_date, source, keywords_str))
                    
                    if cursor.rowcount > 0:
                        saved_count += 1
                        
                except Exception as e:
                    print(f"개별 뉴스 저장 오류: {e}")
                    continue
            
            cursor.close()
            return saved_count
            
        except Exception as e:
            print(f"뉴스 저장 오류: {e}")
            return 0
        finally:
            if connection:
                connection.close()
    
    def get_related_articles(self, keywords: List[str], limit: int = 10) -> List[Dict]:
        """키워드 기반으로 관련 기사 조회"""
        if not keywords:
            return []
            
        connection = None
        try:
            connection = self.get_connection()
            cursor = connection.cursor(dictionary=True)
            
            # 키워드 조건 생성 (LIKE를 사용한 검색)
            keyword_conditions = []
            params = []
            
            for keyword in keywords:
                keyword_conditions.append(
                    "(title LIKE %s OR content LIKE %s OR keywords LIKE %s)"
                )
                keyword_like = f'%{keyword}%'
                params.extend([keyword_like, keyword_like, keyword_like])
            
            where_clause = " OR ".join(keyword_conditions)
            
            query = f'''
            SELECT title, content, url, source, keywords, published_date
            FROM news_articles 
            WHERE {where_clause}
            ORDER BY created_at DESC
            LIMIT %s
            '''
            params.append(limit)
            
            cursor.execute(query, params)
            articles = cursor.fetchall()
            
            cursor.close()
            return articles or []
            
        except Exception as e:
            print(f"관련 기사 조회 오류: {e}")
            return []
        finally:
            if connection:
                connection.close()
    
    def save_analysis_result(self, original_url: str, keywords: List[str], 
                           articles_count: int, summary: str, 
                           reliability_score: float, analysis_details: str) -> int:
        """분석 결과 저장"""
        connection = None
        try:
            connection = self.get_connection()
            cursor = connection.cursor()
            
            keywords_str = ','.join(keywords) if keywords else ''
            
            cursor.execute('''
            INSERT INTO analysis_results 
            (original_url, extracted_keywords, related_articles_count, 
             summary, reliability_score, analysis_details)
            VALUES (%s, %s, %s, %s, %s, %s)
            ''', (
                original_url, keywords_str, articles_count,
                summary, reliability_score, analysis_details
            ))
            
            result_id = cursor.lastrowid
            cursor.close()
            return result_id
            
        except Exception as e:
            print(f"분석 결과 저장 오류: {e}")
            return 0
        finally:
            if connection:
                connection.close()
    
    def save_keyword_extraction(self, source_url: str, keywords: List[str], method: str):
        """키워드 추출 로그 저장"""
        connection = None
        try:
            connection = self.get_connection()
            cursor = connection.cursor()
            
            keywords_str = ','.join(keywords) if keywords else ''
            
            cursor.execute('''
            INSERT INTO keyword_extractions 
            (source_url, extracted_keywords, extraction_method)
            VALUES (%s, %s, %s)
            ''', (source_url, keywords_str, method))
            
            cursor.close()
            
        except Exception as e:
            print(f"키워드 추출 로그 저장 오류: {e}")
        finally:
            if connection:
                connection.close()
    
    def get_analysis_history(self, limit: int = 20) -> List[Dict]:
        """분석 기록 조회"""
        connection = None
        try:
            connection = self.get_connection()
            cursor = connection.cursor(dictionary=True)
            
            cursor.execute('''
            SELECT original_url, extracted_keywords, related_articles_count,
                   reliability_score, created_at
            FROM analysis_results 
            ORDER BY created_at DESC
            LIMIT %s
            ''', (limit,))
            
            history = cursor.fetchall()
            cursor.close()
            
            # 결과 정리
            for item in history:
                item['keywords'] = item['extracted_keywords'] or ''
                item['articles_count'] = item['related_articles_count'] or 0
                item['reliability_score'] = float(item['reliability_score'] or 0)
            
            return history or []
            
        except Exception as e:
            print(f"분석 기록 조회 오류: {e}")
            return []
        finally:
            if connection:
                connection.close()
    
    def get_analysis_by_id(self, analysis_id: int) -> Optional[Dict]:
        """ID로 특정 분석 결과 조회"""
        connection = None
        try:
            connection = self.get_connection()
            cursor = connection.cursor(dictionary=True)
            
            cursor.execute('''
            SELECT * FROM analysis_results WHERE id = %s
            ''', (analysis_id,))
            
            result = cursor.fetchone()
            cursor.close()
            
            if result:
                result['keywords'] = result['extracted_keywords'].split(',') if result['extracted_keywords'] else []
                result['articles_count'] = result['related_articles_count'] or 0
                result['reliability_score'] = float(result['reliability_score'] or 0)
            
            return result
            
        except Exception as e:
            print(f"분석 결과 조회 오류: {e}")
            return None
        finally:
            if connection:
                connection.close()
    
    def cleanup_old_data(self, days: int = 30) -> int:
        """오래된 데이터 정리"""
        connection = None
        try:
            connection = self.get_connection()
            cursor = connection.cursor()
            
            # 오래된 뉴스 기사 삭제
            cursor.execute('''
            DELETE FROM news_articles 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL %s DAY)
            ''', (days,))
            
            deleted_articles = cursor.rowcount
            
            # 오래된 키워드 추출 로그 삭제
            cursor.execute('''
            DELETE FROM keyword_extractions 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL %s DAY)
            ''', (days,))
            
            deleted_extractions = cursor.rowcount
            total_deleted = deleted_articles + deleted_extractions
            
            cursor.close()
            return total_deleted
            
        except Exception as e:
            print(f"데이터 정리 오류: {e}")
            return 0
        finally:
            if connection:
                connection.close()
    
    def get_statistics(self) -> Dict:
        """통계 정보 조회"""
        connection = None
        try:
            connection = self.get_connection()
            cursor = connection.cursor(dictionary=True)
            
            # 전체 분석 수
            cursor.execute("SELECT COUNT(*) as total FROM analysis_results")
            total_analyses = cursor.fetchone()['total']
            
            # 평균 신뢰도
            cursor.execute("SELECT AVG(reliability_score) as avg_score FROM analysis_results")
            avg_result = cursor.fetchone()
            avg_reliability = float(avg_result['avg_score'] or 0)
            
            # 신뢰도별 분포
            cursor.execute("""
            SELECT 
                SUM(CASE WHEN reliability_score >= 80 THEN 1 ELSE 0 END) as high,
                SUM(CASE WHEN reliability_score >= 60 AND reliability_score < 80 THEN 1 ELSE 0 END) as medium,
                SUM(CASE WHEN reliability_score < 60 THEN 1 ELSE 0 END) as low
            FROM analysis_results
            """)
            distribution = cursor.fetchone()
            
            # 오늘 분석 수
            cursor.execute("""
            SELECT COUNT(*) as today_count 
            FROM analysis_results 
            WHERE DATE(created_at) = CURDATE()
            """)
            today_analyses = cursor.fetchone()['today_count']
            
            cursor.close()
            
            return {
                'total_analyses': total_analyses,
                'average_reliability': round(avg_reliability, 1),
                'reliability_distribution': {
                    'high': distribution['high'] or 0,
                    'medium': distribution['medium'] or 0,
                    'low': distribution['low'] or 0
                },
                'today_analyses': today_analyses
            }
            
        except Exception as e:
            print(f"통계 조회 오류: {e}")
            return {
                'total_analyses': 0,
                'average_reliability': 0,
                'reliability_distribution': {'high': 0, 'medium': 0, 'low': 0},
                'today_analyses': 0
            }
        finally:
            if connection:
                connection.close()
    
    def _clean_text(self, text: str) -> str:
        """텍스트 정리 (HTML 태그 제거 등)"""
        if not text:
            return ""
        
        # HTML 태그 제거
        text = re.sub(r'<[^>]+>', '', text)
        # HTML 엔티티 디코딩
        text = text.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
        text = text.replace('&quot;', '"').replace('&#39;', "'").replace('&nbsp;', ' ')
        # 연속된 공백 정리
        text = re.sub(r'\s+', ' ', text.strip())
        
        return text

    def test_connection(self) -> bool:
        """데이터베이스 연결 테스트"""
        try:
            connection = self.get_connection()
            cursor = connection.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            cursor.close()
            connection.close()
            print("MySQL 데이터베이스 연결 성공")
            return True
        except Exception as e:
            print(f"MySQL 데이터베이스 연결 실패: {e}")
            return False

# 테스트 함수
def test_database():
    """데이터베이스 연결 및 기능 테스트"""
    db = DatabaseManager()
    
    if db.test_connection():
        print("✅ 데이터베이스 연결 성공")
        
        # 통계 테스트
        stats = db.get_statistics()
        print(f"📊 현재 통계: {stats}")
        
        # 기록 조회 테스트
        history = db.get_analysis_history(5)
        print(f"📜 최근 분석 기록: {len(history)}건")
        
    else:
        print("❌ 데이터베이스 연결 실패")
        print("설정을 확인해주세요:")
        print(f"- Host: {Config.MYSQL_HOST}")
        print(f"- Port: {Config.MYSQL_PORT}")
        print(f"- Database: {Config.MYSQL_DATABASE}")
        print(f"- User: {Config.MYSQL_USER}")

if __name__ == "__main__":
    test_database()