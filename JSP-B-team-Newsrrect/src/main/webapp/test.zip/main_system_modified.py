from flask import Flask, render_template, request, jsonify
import json
from datetime import datetime
from typing import Dict, List
import traceback
import time
import socket

# 우리가 만든 모듈들 import
from config import Config
from database import DatabaseManager
from keyword_extractor import KeywordExtractor
from news_searcher import NaverNewsSearcher
from news_analyzer import NewsAnalyzer

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'

class ModifiedNewsAnalysisSystem:
    def __init__(self):
        self.db_manager = DatabaseManager()
        self.keyword_extractor = KeywordExtractor()
        self.news_searcher = NaverNewsSearcher()
        self.news_analyzer = NewsAnalyzer()

    def analyze_news_url(self, url: str) -> Dict:
        """URL 기반 뉴스 분석: 해당 글만 요약하고, 팩트체킹은 관련 뉴스로 수행"""
        start_time = time.time()

        try:
            print(f"뉴스 분석 시작 (URL): {url}")

            # 1단계: 원본 URL에서 콘텐츠 추출
            print("1단계: 원본 URL에서 콘텐츠 추출 중...")
            content_result = self.keyword_extractor.extract_content_from_url(url)

            if not content_result['title'] and not content_result['content']:
                return {
                    'success': False,
                    'error': f"URL에서 콘텐츠를 추출할 수 없습니다: {url}",
                    'stage': 'content_extraction'
                }

            original_title = content_result['title']
            original_content = content_result['content']
            domain = content_result['domain']

            print(f"원본 제목: {original_title[:50]}...")
            print(f"원본 내용 길이: {len(original_content)} 글자")

            # 2단계: 원본 글에서 키워드 추출
            print("2단계: 원본 글에서 키워드 추출 중...")
            full_text = f"{original_title}\n\n{original_content}"
            keywords = self.keyword_extractor.extract_keywords_with_cohere(full_text)

            if not keywords:
                return {
                    'success': False,
                    'error': "원본 글에서 키워드를 추출할 수 없습니다.",
                    'stage': 'keyword_extraction'
                }

            print(f"추출된 키워드: {keywords}")

            # 키워드 추출 로그 저장
            self.db_manager.save_keyword_extraction(url, keywords, 'cohere_from_url')

            # 3단계: 원본 글만으로 요약 생성
            print("3단계: 원본 글 요약 생성 중...")
            original_summary = self._generate_original_summary(full_text, original_title)

            # 4단계: 팩트체킹을 위한 관련 뉴스 검색
            print("4단계: 팩트체킹을 위한 관련 뉴스 검색 중...")
            search_result = self.news_searcher.get_top_articles(keywords)

            if not search_result['success']:
                # 관련 뉴스 없어도 원본 요약은 제공
                return {
                    'success': True,
                    'result_id': 0,
                    'url': url,
                    'title': original_title,
                    'domain': domain,
                    'keywords': keywords,
                    'original_summary': original_summary,
                    'fact_check_available': False,
                    'reliability_score': 50.0,  # 기본값
                    'verification_details': "관련 뉴스를 찾을 수 없어 팩트체킹을 수행할 수 없습니다.",
                    'articles_analyzed': 0,
                    'processing_time': round(time.time() - start_time, 2),
                    'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }

            related_articles = search_result['top_articles']
            print(f"팩트체킹용 관련 뉴스: {len(related_articles)}건 발견")

            # 5단계: 관련 뉴스 DB 저장
            print("5단계: 관련 뉴스 DB 저장 중...")
            saved_count = self.db_manager.save_news_articles(related_articles, keywords)
            print(f"저장된 뉴스: {saved_count}건")

            # 6단계: 팩트체킹 수행 (관련 뉴스와 비교)
            print("6단계: 팩트체킹 수행 중...")
            fact_check_result = self._perform_fact_checking(
                original_title, original_content, related_articles, keywords
            )

            # 처리 시간 계산
            processing_time = time.time() - start_time

            # 7단계: 결과 저장
            print("7단계: 최종 분석 결과 저장 중...")
            result_id = self.db_manager.save_analysis_result(
                url, keywords, len(related_articles),
                original_summary,  # 원본 글 요약 저장
                fact_check_result['reliability_score'],
                fact_check_result['verification_details']
            )

            print(f"분석 완료! (처리시간: {processing_time:.2f}초)")

            return {
                'success': True,
                'result_id': result_id,
                'url': url,
                'title': original_title,
                'domain': domain,
                'keywords': keywords,
                'original_summary': original_summary,  # 원본 글만의 요약
                'fact_check_available': True,
                'reliability_score': fact_check_result['reliability_score'],
                'verification_details': fact_check_result['verification_details'],
                'articles_analyzed': len(related_articles),
                'articles_info': fact_check_result['articles_info'],
                'search_summary': search_result.get('search_summary', {}),
                'processing_time': round(processing_time, 2),
                'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }

        except Exception as e:
            error_msg = f"시스템 오류 (URL 분석): {str(e)}"
            print(error_msg)
            traceback.print_exc()

            return {
                'success': False,
                'error': error_msg,
                'stage': 'system_error'
            }

    def analyze_news_text(self, text: str) -> Dict:
        """텍스트 기반 뉴스 분석: 해당 텍스트만 요약하고, 팩트체킹은 관련 뉴스로 수행"""
        start_time = time.time()
        
        # DB에 저장할 고유 식별자 생성
        source_identifier = f"text-analysis:{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        try:
            print(f"뉴스 분석 시작 (Text): {text[:100]}...")

            if len(text.strip()) < 50:
                return {
                    'success': False,
                    'error': "분석하기에는 텍스트가 너무 짧습니다. (최소 50자 이상)",
                    'stage': 'text_validation'
                }

            # 1단계: 텍스트에서 키워드 추출
            print("1단계: 텍스트에서 키워드 추출 중...")
            keywords = self.keyword_extractor.extract_keywords_with_cohere(text)

            if not keywords:
                return {
                    'success': False,
                    'error': "텍스트에서 키워드를 추출할 수 없습니다.",
                    'stage': 'keyword_extraction'
                }
            
            print(f"추출된 키워드: {keywords}")

            # 키워드 추출 로그 저장
            self.db_manager.save_keyword_extraction(source_identifier, keywords, 'cohere_from_text')

            # 2단계: 입력 텍스트만으로 요약 생성
            print("2단계: 입력 텍스트 요약 생성 중...")
            original_summary = self._generate_original_summary(text, "사용자 입력 텍스트")

            # 3단계: 팩트체킹을 위한 관련 뉴스 검색
            print("3단계: 팩트체킹을 위한 관련 뉴스 검색 중...")
            search_result = self.news_searcher.get_top_articles(keywords)

            if not search_result['success']:
                # 관련 뉴스 없어도 원본 요약은 제공
                return {
                    'success': True,
                    'result_id': 0,
                    'source': 'text_input',
                    'title': '텍스트 분석',
                    'keywords': keywords,
                    'original_summary': original_summary,
                    'fact_check_available': False,
                    'reliability_score': 50.0,  # 기본값
                    'verification_details': "관련 뉴스를 찾을 수 없어 팩트체킹을 수행할 수 없습니다.",
                    'articles_analyzed': 0,
                    'processing_time': round(time.time() - start_time, 2),
                    'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }

            related_articles = search_result['top_articles']
            print(f"팩트체킹용 관련 뉴스: {len(related_articles)}건 발견")

            # 4단계: 관련 뉴스 DB 저장
            print("4단계: 관련 뉴스 DB 저장 중...")
            saved_count = self.db_manager.save_news_articles(related_articles, keywords)
            print(f"저장된 뉴스: {saved_count}건")

            # 5단계: 팩트체킹 수행
            print("5단계: 팩트체킹 수행 중...")
            fact_check_result = self._perform_fact_checking(
                "텍스트 분석", text, related_articles, keywords
            )

            # 처리 시간 계산
            processing_time = time.time() - start_time

            # 6단계: 결과 저장
            print("6단계: 최종 분석 결과 저장 중...")
            result_id = self.db_manager.save_analysis_result(
                source_identifier, keywords, len(related_articles),
                original_summary,  # 원본 텍스트 요약 저장
                fact_check_result['reliability_score'],
                fact_check_result['verification_details']
            )

            print(f"분석 완료! (처리시간: {processing_time:.2f}초)")

            return {
                'success': True,
                'result_id': result_id,
                'source': 'text_input',
                'title': '텍스트 분석',
                'keywords': keywords,
                'original_summary': original_summary,  # 원본 텍스트만의 요약
                'fact_check_available': True,
                'reliability_score': fact_check_result['reliability_score'],
                'verification_details': fact_check_result['verification_details'],
                'articles_analyzed': len(related_articles),
                'articles_info': fact_check_result['articles_info'],
                'search_summary': search_result.get('search_summary', {}),
                'processing_time': round(processing_time, 2),
                'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }

        except Exception as e:
            error_msg = f"시스템 오류 (텍스트 분석): {str(e)}"
            print(error_msg)
            traceback.print_exc()

            return {
                'success': False,
                'error': error_msg,
                'stage': 'system_error'
            }

    def _generate_original_summary(self, text: str, title: str = "") -> str:
        """원본 글만을 사용한 요약 생성"""
        try:
            # 텍스트가 너무 길면 앞부분만 사용
            max_length = 3000
            if len(text) > max_length:
                text = text[:max_length] + "..."

            # AI 요약 프롬프트
            prompt = f"""다음 글의 핵심 내용을 3-4문장으로 간결하고 명확하게 요약해주세요. 
원문의 주요 논점과 핵심 정보만 포함하고, 추가적인 해석이나 추측은 하지 마세요.

제목: {title}

원문:
{text}

요약:"""

            print("Cohere API로 원본 글 요약 생성 중...")
            
            if not self.news_analyzer.cohere_client:
                print("Cohere 클라이언트 없음, 기본 요약 사용")
                return self._create_fallback_summary(title, text)

            # 여러 모델 시도
            models_to_try = ['command-r-plus', 'command-r', 'command']
            
            for model in models_to_try:
                try:
                    response = self.news_analyzer.cohere_client.generate(
                        model=model,
                        prompt=prompt,
                        max_tokens=250,
                        temperature=0.2,  # 낮은 temperature로 정확성 향상
                        k=0,
                        p=0.85
                    )
                    
                    summary = response.generations[0].text.strip()
                    if summary and len(summary) > 30:
                        print(f"원본 요약 생성 성공 (모델: {model})")
                        return self._clean_summary(summary)
                        
                except Exception as model_error:
                    print(f"모델 {model} 실패: {model_error}")
                    continue
            
            # 모든 모델 실패시 폴백
            print("모든 AI 모델 실패, 기본 요약 사용")
            return self._create_fallback_summary(title, text)
            
        except Exception as e:
            print(f"원본 요약 생성 오류: {e}")
            return self._create_fallback_summary(title, text)

    def _perform_fact_checking(self, title: str, content: str, related_articles: List[Dict], keywords: List[str]) -> Dict:
        """원본 글과 관련 뉴스를 비교하여 팩트체킹 수행"""
        try:
            print("  - 팩트체킹 분석 시작...")

            # 신뢰성 점수 계산
            reliability_score = self._calculate_reliability_score(content, related_articles, keywords)

            # 검증 상세 내용 생성
            verification_details = self._generate_verification_details(
                title, content, related_articles, reliability_score
            )

            # 관련 기사 정보 생성
            articles_info = [
                {
                    'title': article.get('title', ''),
                    'source': article.get('bloggername', '') or article.get('source', '') or article.get('domain', ''),
                    'pub_date': article.get('pub_date', '') or article.get('published_date', ''),
                    'relevance_score': article.get('relevance_score', 0),
                    'url': article.get('link', '') or article.get('url', '')
                }
                for article in related_articles
            ]

            print(f"  - 팩트체킹 완료 (신뢰도: {reliability_score:.1f}%)")

            return {
                'reliability_score': reliability_score,
                'verification_details': verification_details,
                'articles_info': articles_info
            }

        except Exception as e:
            print(f"  - 팩트체킹 오류: {e}")
            return {
                'reliability_score': 50.0,
                'verification_details': f"팩트체킹 중 오류 발생: {str(e)}",
                'articles_info': []
            }

    def _calculate_reliability_score(self, original_content: str, related_articles: List[Dict], keywords: List[str]) -> float:
        """신뢰성 점수 계산"""
        base_score = 30.0
        
        # 관련 기사 개수에 따른 점수
        if len(related_articles) >= 5:
            base_score += 25
        elif len(related_articles) >= 3:
            base_score += 15
        elif len(related_articles) >= 1:
            base_score += 10

        # 키워드 매칭 점수
        keyword_matches = 0
        original_lower = original_content.lower()
        
        for article in related_articles:
            title = article.get('title', '').lower()
            description = article.get('description', '').lower()
            
            for keyword in keywords:
                if keyword.lower() in original_lower and (keyword.lower() in title or keyword.lower() in description):
                    keyword_matches += 1

        if keyword_matches > len(keywords) * 2:
            base_score += 20
        elif keyword_matches > len(keywords):
            base_score += 15
        elif keyword_matches > 0:
            base_score += 10

        # 언론사 기사 비율
        press_articles = sum(1 for article in related_articles if article.get('is_press', False))
        if related_articles:
            press_ratio = press_articles / len(related_articles)
            base_score += press_ratio * 15

        # 최근 기사 비율
        recent_articles = sum(1 for article in related_articles 
                            if article.get('pub_date', '') and '2024' in article.get('pub_date', ''))
        if related_articles:
            recent_ratio = recent_articles / len(related_articles)
            base_score += recent_ratio * 10

        return min(100.0, max(0.0, base_score))

    def _generate_verification_details(self, title: str, content: str, related_articles: List[Dict], score: float) -> str:
        """검증 상세 내용 생성"""
        details = [
            f"분석 대상: {title}",
            f"관련 뉴스 발견: {len(related_articles)}건",
            f"신뢰성 점수: {score:.1f}%"
        ]

        if score >= 80:
            details.append("높은 신뢰도: 여러 관련 뉴스에서 유사한 내용이 확인됩니다.")
        elif score >= 60:
            details.append("중간 신뢰도: 일부 관련 뉴스에서 내용이 확인됩니다.")
        else:
            details.append("낮은 신뢰도: 관련 뉴스가 부족하거나 내용 확인이 어렵습니다.")

        if related_articles:
            press_count = sum(1 for article in related_articles if article.get('is_press', False))
            details.append(f"언론사 기사: {press_count}/{len(related_articles)}건")
            
            if press_count > 0:
                details.append("주요 언론사에서 관련 내용을 보도했습니다.")

        return "\n".join(details)

    def _create_fallback_summary(self, title: str, content: str) -> str:
        """AI 없이 간단한 요약 생성"""
        if not content.strip():
            return "요약할 내용이 없습니다."
        
        # 첫 300자 정도를 요약으로 사용하되, 문장 단위로 자름
        summary_length = min(300, len(content))
        summary = content[:summary_length]
        
        # 마지막 완전한 문장까지만 포함
        sentences = summary.split('.')
        if len(sentences) > 1:
            complete_sentences = sentences[:-1]  # 마지막 불완전한 문장 제외
            summary = '. '.join(complete_sentences) + '.'
        
        return summary.strip()

    def _clean_summary(self, summary: str) -> str:
        """요약 텍스트 정리"""
        # 불필요한 접두사 제거
        prefixes_to_remove = [
            "요약:", "다음은", "간단히", "[요약]", "내용 요약:", "핵심 요약:", "간단 요약:"
        ]
        
        for prefix in prefixes_to_remove:
            if summary.strip().startswith(prefix):
                summary = summary.strip()[len(prefix):].strip()
        
        return summary.strip()


# 시스템 인스턴스 생성
modified_system = ModifiedNewsAnalysisSystem()

# 웹 라우트들
@app.route('/')
def index():
    """메인 페이지"""
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze_news():
    """수정된 뉴스 분석 API (원본 요약 + 팩트체킹)"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': '잘못된 요청입니다.'}), 400
            
        url = data.get('url', '').strip()
        text = data.get('text', '').strip()

        if not url and not text:
            return jsonify({
                'success': False,
                'error': '분석할 URL 또는 텍스트를 입력해주세요.'
            }), 400

        # URL이 우선순위를 가짐
        if url:
            # URL 유효성 간단 검증
            if not (url.startswith('http://') or url.startswith('https://')):
                return jsonify({
                    'success': False,
                    'error': '올바른 URL 형식이 아닙니다.'
                }), 400
            
            # URL 분석 실행
            result = modified_system.analyze_news_url(url)
        else:
            # 텍스트 분석 실행
            result = modified_system.analyze_news_text(text)

        return jsonify(result)

    except Exception as e:
        print(f"Analyze API 오류: {e}")
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': f'서버 오류: {str(e)}'
        }), 500

# 나머지 라우트들은 기존과 동일
@app.route('/history')
def get_history():
    """분석 기록 조회"""
    try:
        limit = request.args.get('limit', 20, type=int)
        history = modified_system.db_manager.get_analysis_history(limit)
        
        return jsonify({
            'success': True,
            'history': history
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'기록 조회 오류: {str(e)}'
        })

@app.route('/result/<int:result_id>')
def get_result_detail(result_id):
    """특정 분석 결과 상세 조회"""
    try:
        result = modified_system.db_manager.get_analysis_by_id(result_id)
        
        if not result:
            return jsonify({
                'success': False,
                'error': '해당 분석 결과를 찾을 수 없습니다.'
            })
        
        return jsonify({
            'success': True,
            'result': result
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'결과 조회 오류: {str(e)}'
        })

@app.route('/health')
def health_check():
    """시스템 상태 확인"""
    try:
        # 데이터베이스 연결 테스트
        db_status = modified_system.db_manager.test_connection()
        
        # 기본 통계 조회
        stats = modified_system.db_manager.get_statistics()
        
        return jsonify({
            'status': 'healthy' if db_status else 'unhealthy',
            'database': 'connected' if db_status else 'disconnected',
            'timestamp': datetime.now().isoformat(),
            'stats': stats
        })
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        })

# 에러 핸들러
@app.errorhandler(404)
def not_found_error(error):
    return jsonify({
        'success': False,
        'error': '요청한 페이지를 찾을 수 없습니다.'
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'success': False,
        'error': '서버 내부 오류가 발생했습니다.'
    }), 500

def initialize_system():
    """시스템 초기화"""
    print("시스템 초기화 중...")
    
    try:
        # 데이터베이스 연결 테스트
        if not modified_system.db_manager.test_connection():
            print("데이터베이스 연결 실패")
            return False
        
        print("시스템 초기화 완료")
        return True
        
    except Exception as e:
        print(f"시스템 초기화 실패: {e}")
        return False

if __name__ == "__main__":
    import sys
    
    # 시스템 초기화
    if not initialize_system():
        print("시스템을 시작할 수 없습니다.")
        sys.exit(1)
    
    # 현재 컴퓨터의 IP 주소 확인
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    
    print("수정된 뉴스 분석 시스템을 웹 서버 모드로 시작합니다...")
    print("주요 변경사항: 요약은 원본 글만 사용, 팩트체킹은 관련 뉴스로 수행")
    print(f"로컬 접속: http://localhost:{Config.PORT}")
    print(f"네트워크 접속: http://{local_ip}:{Config.PORT}")
    
    try:
        app.run(
            host=Config.HOST, 
            port=Config.PORT, 
            debug=Config.DEBUG,
            threaded=True
        )
    except KeyboardInterrupt:
        print("\n서버를 종료합니다.")
    except Exception as e:
        print(f"서버 실행 오류: {e}")