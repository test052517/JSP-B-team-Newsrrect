import cohere
import re
from typing import List, Dict, Tuple
from datetime import datetime
from config import Config
import time

class NewsAnalyzer:
    def __init__(self):
        try:
            self.cohere_client = cohere.Client(Config.COHERE_API_KEY)
            print(f"Cohere 클라이언트 초기화 성공 (API 키: {Config.COHERE_API_KEY[:10]}...)")
        except Exception as e:
            print(f"Cohere 클라이언트 초기화 실패: {e}")
            self.cohere_client = None
    
    def test_cohere_connection(self) -> bool:
        """Cohere API 연결 테스트"""
        if not self.cohere_client:
            return False
        
        try:
            response = self.cohere_client.generate(
                model='command-r-plus',
                prompt="안녕하세요. 한 문장으로 답해주세요.",
                max_tokens=50,
                temperature=0.3
            )
            print("Cohere API 연결 테스트 성공")
            return True
        except Exception as e:
            print(f"Cohere API 연결 테스트 실패: {e}")
            return False
    
    def summarize_articles(self, articles: List[Dict]) -> str:
        """여러 뉴스 기사를 종합 요약 (문단 요약만 생성)"""
        if not self.cohere_client:
            return "AI 분석 서비스에 연결할 수 없습니다. API 키를 확인해주세요."
        
        try:
            combined_text = self._combine_articles_text(articles)
            
            if not combined_text.strip():
                return "요약할 내용이 없습니다."
            
            print(f"요약할 텍스트 길이: {len(combined_text)} 글자")
            
            # AI 프롬프트 수정: 완결된 문단 요약만 요청
            prompt = f"""당신은 전문 뉴스 편집자입니다. 다음 뉴스 기사들의 핵심 내용을 종합하여, 사람들이 이해하기 쉽게 3~4문장의 완결된 문단으로 요약해주세요. 서론이나 부가 설명 없이 핵심 요약 본문만 작성해주세요.

[뉴스 내용]
{combined_text[:2000]}

[핵심 요약]
"""

            print("Cohere API로 문단 요약 생성 중...")
            
            models_to_try = ['command-r-plus', 'command-r', 'command']
            response = None
            
            for model in models_to_try:
                try:
                    response = self.cohere_client.generate(
                        model=model,
                        prompt=prompt,
                        max_tokens=300, # 요약에 집중하므로 토큰을 약간 줄임
                        temperature=0.3,
                        k=0,
                        p=0.9
                    )
                    break 
                except Exception as model_error:
                    print(f"모델 {model} 실패: {model_error}")
                    continue
            
            if response is None:
                raise Exception("모든 Cohere 모델 호출에 실패했습니다.")

            summary = response.generations[0].text.strip()
            print(f"요약 생성 성공: {len(summary)} 글자")
            return self._clean_summary(summary)
            
        except Exception as e:
            error_msg = f"요약 생성 오류: {str(e)}"
            print(error_msg)
            return self._fallback_summary(articles)
    
    def cross_verify_articles(self, articles: List[Dict], keywords: List[str]) -> Tuple[float, str]:
        """교차검증을 통한 신뢰성 평가"""
        if not self.cohere_client:
            return 65.0, "AI 분석 서비스에 연결할 수 없어 기본 신뢰도로 평가했습니다."
        
        try:
            basic_score = self._calculate_basic_reliability(articles, keywords)
            
            if len(articles) < 2:
                return basic_score, f"분석할 기사가 {len(articles)}개로 부족합니다. 기본 분석을 수행했습니다."
            
            analysis_text = self._prepare_verification_text(articles[:3])
            
            prompt = f"""다음 뉴스 기사들의 신뢰성을 평가해주세요.

평가 기준:
1. 여러 기사에서 동일한 내용이 나오는가?
2. 구체적인 정보(날짜, 수치, 인물명)가 있는가?
3. 서로 모순되는 내용이 있는가?

뉴스 기사들:
{analysis_text[:1500]}

100점 만점으로 신뢰성 점수를 매기고 간단히 설명해주세요.
점수: """

            print("Cohere API로 신뢰성 분석 중...")
            
            response = self.cohere_client.generate(
                model='command-r-plus',
                prompt=prompt,
                max_tokens=400,
                temperature=0.2,
                k=0,
                p=0.8
            )
            
            verification_result = response.generations[0].text.strip()
            
            reliability_score = self._extract_reliability_score(verification_result)
            
            print(f"신뢰성 분석 성공: {reliability_score}점")
            
            return reliability_score, verification_result
            
        except Exception as e:
            error_msg = f"교차검증 오류: {str(e)}"
            print(error_msg)
            
            basic_score = self._calculate_basic_reliability(articles, keywords)
            return basic_score, f"AI 분석 실패로 기본 분석을 수행했습니다. 기사 수: {len(articles)}개"
    
    def _calculate_basic_reliability(self, articles: List[Dict], keywords: List[str]) -> float:
        """기본 신뢰성 계산 (AI 없이)"""
        score = 25.0
        
        if not articles:
            return score

        total_relevance = sum(article.get('relevance_score', 0) for article in articles)
        avg_relevance = total_relevance / len(articles)
        
        if avg_relevance >= 9:
            score += 20
        elif avg_relevance >= 7:
            score += 15
        elif avg_relevance >= 5:
            score += 10
        elif avg_relevance >= 3:
            score += 5
            
        if len(articles) >= 5:
            score += 15
        elif len(articles) >= 3:
            score += 7
        elif len(articles) >= 2:
            score += 3
        
        keyword_matches = 0
        for article in articles:
            title = article.get('title', '').lower()
            content = article.get('description', '').lower()
            
            for keyword in keywords:
                if keyword.lower() in title or keyword.lower() in content:
                    keyword_matches += 1
        
        if keyword_matches > len(keywords) * len(articles) * 0.5:
            score += 15
        elif keyword_matches > len(keywords):
            score += 10
        
        sources = set()
        for article in articles:
            source = article.get('bloggername', '') or article.get('source', '')
            if source:
                sources.add(source)
        
        if len(sources) >= 3:
            score += 10
        elif len(sources) >= 2:
            score += 5
        
        return min(100.0, max(0.0, score))
    
    def _fallback_summary(self, articles: List[Dict]) -> str:
        """AI 없이 간단한 요약 생성"""
        if not articles:
            return "분석할 기사가 없습니다."
        
        titles = []
        for article in articles[:3]:
            title = article.get('title', '')
            if title and len(title) > 10:
                titles.append(title)
        
        if titles:
            return f"주요 기사들: {', '.join(titles[:2])} 등 {len(articles)}개 기사를 분석했습니다."
        else:
            return f"{len(articles)}개의 관련 기사를 발견했으나 상세 요약을 생성할 수 없습니다."
    
    def _combine_articles_text(self, articles: List[Dict], max_length: int = 2000) -> str:
        """기사들을 텍스트로 결합"""
        combined_parts = []
        current_length = 0
        
        for i, article in enumerate(articles, 1):
            title = article.get('title', '')
            description = article.get('description', '') or article.get('content', '')
            article_text = f"[기사 {i}] {title}\n{description}\n"
            
            if current_length + len(article_text) > max_length:
                break
                
            combined_parts.append(article_text)
            current_length += len(article_text)
        
        return "\n".join(combined_parts)
    
    def _prepare_verification_text(self, articles: List[Dict]) -> str:
        """교차검증을 위한 텍스트 준비"""
        verification_parts = []
        
        for i, article in enumerate(articles, 1):
            title = article.get('title', '')
            description = article.get('description', '') or article.get('content', '')
            source = article.get('bloggername', '') or article.get('source', '') or article.get('domain', '')
            article_info = f"기사 {i}: {title}\n내용: {description[:200]}...\n출처: {source}\n"
            verification_parts.append(article_info)
        
        return "\n".join(verification_parts)
    
    def _extract_reliability_score(self, verification_text: str) -> float:
        """검증 결과에서 신뢰성 점수 추출"""
        patterns = [
            r'점수:\s*(\d+(?:\.\d+)?)',
            r'신뢰성:\s*(\d+(?:\.\d+)?)',
            r'(\d+(?:\.\d+)?)점',
            r'(\d+(?:\.\d+)?)%'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, verification_text)
            if match:
                score = float(match.group(1))
                return min(score, 100.0)
        
        return self._estimate_score_from_text(verification_text)
    
    def _estimate_score_from_text(self, text: str) -> float:
        """텍스트 분석으로 점수 추정"""
        text_lower = text.lower()
        
        positive_indicators = ['신뢰', '정확', '일치', '확인', '구체적']
        negative_indicators = ['의심', '불일치', '모순', '불명확', '추측']
        
        positive_count = sum(1 for indicator in positive_indicators if indicator in text_lower)
        negative_count = sum(1 for indicator in negative_indicators if indicator in text_lower)
        
        base_score = 65.0
        score_adjustment = (positive_count * 8) - (negative_count * 12)
        
        estimated_score = base_score + score_adjustment
        return max(0.0, min(100.0, estimated_score))
    
    def _clean_summary(self, summary: str) -> str:
        """요약 텍스트 정리"""
        prefixes_to_remove = [
            "간단 요약:", "요약:", "다음은 요약입니다:", "기사 요약:", "[분석 결과]", "[핵심 요약]"
        ]
        
        for prefix in prefixes_to_remove:
            if summary.lstrip().startswith(prefix):
                summary = summary.lstrip()[len(prefix):].strip()
        
        summary = re.sub(r'\n\s*\n', '\n\n', summary)
        return summary.strip()
    
    def generate_fact_check_report(self, articles: List[Dict], keywords: List[str]) -> Dict:
        """팩트체크 보고서 생성"""
        try:
            start_time = time.time()
            
            print(f"  - {len(articles)}개 기사로 팩트체크 보고서 생성 시작")
            
            if self.cohere_client:
                connection_ok = self.test_cohere_connection()
                if not connection_ok:
                    print("  - Cohere API 연결 실패, 기본 분석으로 진행")
            
            print("  - 종합 요약 생성 중...")
            summary = self.summarize_articles(articles)
            
            print("  - 교차검증 수행 중...")
            reliability_score, verification_details = self.cross_verify_articles(articles, keywords)
            
            processing_time = time.time() - start_time
            
            report = {
                'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'keywords': keywords,
                'articles_analyzed': len(articles),
                'summary': summary,
                'reliability_score': reliability_score,
                'verification_details': verification_details,
                'sentiment_analysis': '',
                'processing_time': round(processing_time, 2),
                'articles_info': [
                    {
                        'title': article.get('title', ''),
                        'source': article.get('bloggername', '') or article.get('source', '') or article.get('domain', ''),
                        'pub_date': article.get('pub_date', '') or article.get('published_date', ''),
                        'relevance_score': article.get('relevance_score', 0),
                        'url': article.get('link', '') or article.get('url', '')
                    }
                    for article in articles
                ]
            }
            
            print(f"  - 보고서 생성 완료 (신뢰도: {reliability_score:.1f}%)")
            
            return {'success': True, 'report': report}
            
        except Exception as e:
            error_msg = f'보고서 생성 오류: {str(e)}'
            print(f"  - {error_msg}")
            return {'success': False, 'error': error_msg, 'report': {}}