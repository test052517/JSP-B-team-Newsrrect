import os

# .env 파일 로드 (선택적)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    print("python-dotenv가 설치되지 않음. 환경변수를 직접 설정하세요.")

class Config:
    # API 키 설정
    COHERE_API_KEY = os.getenv('COHERE_API_KEY', '59qrJhWKhPGA9WcMvFYGdHiA5YCIpIqORC23TwZx')
    NAVER_CLIENT_ID = os.getenv('NAVER_CLIENT_ID', '0DqSka16EfKk0If8DuuH')
    NAVER_CLIENT_SECRET = os.getenv('NAVER_CLIENT_SECRET', 'x92TmUhBE8')
    
    # MySQL 데이터베이스 설정 (누락된 부분 추가)
    MYSQL_HOST = os.getenv('MYSQL_HOST', 'localhost')
    MYSQL_PORT = int(os.getenv('MYSQL_PORT', 3306))
    MYSQL_USER = os.getenv('MYSQL_USER', 'root')
    MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD', '1234')
    MYSQL_DATABASE = os.getenv('MYSQL_DATABASE', 'news_analysis')
    MYSQL_CHARSET = os.getenv('MYSQL_CHARSET', 'utf8mb4')
    
    # 데이터베이스 설정 (기존 SQLite 설정 - 호환성 유지)
    DATABASE_PATH = 'news_analysis.db'
    
    # 뉴스 수집 설정
    MAX_NEWS_COUNT = int(os.getenv('MAX_NEWS_COUNT', 10))
    KEYWORD_COUNT = int(os.getenv('KEYWORD_COUNT', 8))
    
    # 웹 서버 설정
    HOST = os.getenv('APP_HOST', '0.0.0.0')  # 모든 네트워크 인터페이스에서 접속 허용
    PORT = int(os.getenv('APP_PORT', 5000))
    DEBUG = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'

# 환경변수 설정 예시 (dotenv 없이 사용할 경우)
"""
Windows:
set COHERE_API_KEY=59qrJhWKhPGA9WcMvFYGdHiA5YCIpIqORC23TwZx
set NAVER_CLIENT_ID=0DqSka16EfKk0If8DuuH
set NAVER_CLIENT_SECRET=x92TmUhBE8
set MYSQL_PASSWORD=1234

"""